import adsk.core, adsk.fusion, traceback, math

app = None
ui = None
handlers = []

# ------------------------------------------------------------
# Utility helpers
# ------------------------------------------------------------

def get_design():
    global app
    if not app:
        return None
    return adsk.fusion.Design.cast(app.activeProduct)


def next_index_for_prefix(prefix: str) -> int:
    design = get_design()
    if not design:
        return 1
    root = design.rootComponent
    max_n = 0
    for occ in root.allOccurrences:
        name = occ.component.name
        if not name.startswith(prefix):
            continue
        tail = name[len(prefix):]
        num = ''
        for c in tail:
            if c.isdigit():
                num += c
            else:
                break
        if num:
            try:
                n = int(num)
                if n > max_n:
                    max_n = n
            except:
                pass
    return max_n + 1


def build_frame_from_sketch_line(line: adsk.fusion.SketchLine):
    """
    Build a coordinate frame where:
      - local Z axis = line direction (length axis)
      - origin = midpoint of the line (in world space)
      - X/Y form a perpendicular basis

    Uses SketchLine.worldGeometry for robustness.
    """
    geo = line.worldGeometry  # adsk.core.Line3D
    p0 = geo.startPoint
    p1 = geo.endPoint

    # Midpoint in world
    mid = adsk.core.Point3D.create(
        (p0.x + p1.x) * 0.5,
        (p0.y + p1.y) * 0.5,
        (p0.z + p1.z) * 0.5
    )

    # Z axis = line direction (p0 -> p1)
    z_axis = adsk.core.Vector3D.create(
        p1.x - p0.x,
        p1.y - p0.y,
        p1.z - p0.z
    )
    if z_axis.length == 0:
        z_axis = adsk.core.Vector3D.create(0, 0, 1)
    z_axis.normalize()

    # X axis = any vector perpendicular to Z
    temp = adsk.core.Vector3D.create(0, 1, 0)
    if abs(temp.dotProduct(z_axis)) > 0.99:
        temp = adsk.core.Vector3D.create(1, 0, 0)

    x_axis = temp.crossProduct(z_axis)
    x_axis.normalize()

    # Y axis = Z × X (right-handed)
    y_axis = z_axis.crossProduct(x_axis)
    y_axis.normalize()

    return mid, x_axis, y_axis, z_axis


def orient_occurrence_to_line_center(
    occurrence: adsk.fusion.Occurrence,
    line: adsk.fusion.SketchLine
):
    """
    Orient the occurrence so its local Z axis follows the sketch line direction
    and its origin is at the midpoint of the line.
    """
    global ui
    try:
        mid, x_axis, y_axis, z_axis = build_frame_from_sketch_line(line)
        m = adsk.core.Matrix3D.create()
        m.setWithCoordinateSystem(mid, x_axis, y_axis, z_axis)
        occurrence.transform = m
    except:
        if ui:
            ui.messageBox(
                'orient_occurrence_to_line_center failed:\n{}'.format(
                    traceback.format_exc()
                )
            )

# ------------------------------------------------------------
# EA command handlers
# ------------------------------------------------------------

class EA2HolesCreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self):
        super().__init__()

    def notify(self, args):
        global ui, handlers
        try:
            cmd = args.command
            cmd.isExecutedWhenPreEmpted = False
            inputs = cmd.commandInputs

            sel = inputs.addSelectionInput(
                'lineSel',
                'Construction Line',
                'Select a construction line'
            )
            sel.addSelectionFilter('SketchLines')
            sel.setSelectionLimits(1, 1)

            inputs.addValueInput(
                'flange', 'Flange', 'mm',
                adsk.core.ValueInput.createByString('50 mm')
            )
            inputs.addValueInput(
                'thk', 'Thickness', 'mm',
                adsk.core.ValueInput.createByString('3 mm')
            )
            inputs.addValueInput(
                'endInset', 'Hole End Inset', 'mm',
                adsk.core.ValueInput.createByString('20 mm')
            )
            inputs.addValueInput(
                'sideInset', 'Hole Side Inset', 'mm',
                adsk.core.ValueInput.createByString('25 mm')
            )
            inputs.addValueInput(
                'holeDia', 'Hole Diameter', 'mm',
                adsk.core.ValueInput.createByString('13 mm')
            )
            inputs.addValueInput(
                'rootFillet', 'Root Fillet Radius', 'mm',
                adsk.core.ValueInput.createByString('3 mm')
            )

            inputs.addStringValueInput('prefix', 'Name Prefix', 'EA')
            preview = inputs.addStringValueInput('namePreview', 'Next Name', '')
            preview.isReadOnly = True

            ic = EA2HolesInputChangedHandler()
            cmd.inputChanged.add(ic)
            handlers.append(ic)

            ex = EA2HolesExecuteHandler()
            cmd.execute.add(ex)
            handlers.append(ex)

        except:
            if ui:
                ui.messageBox(
                    'EA2HolesCreatedHandler failed:\n{}'.format(
                        traceback.format_exc()
                    )
                )


class EA2HolesInputChangedHandler(adsk.core.InputChangedEventHandler):
    def __init__(self):
        super().__init__()

    def notify(self, args):
        try:
            inputs = args.inputs
            prefix = inputs.itemById('prefix').value
            idx = next_index_for_prefix(prefix)
            inputs.itemById('namePreview').value = f"{prefix}{idx}"
        except:
            pass


class EA2HolesExecuteHandler(adsk.core.CommandEventHandler):
    def __init__(self):
        super().__init__()

    def notify(self, args):
        global ui
        try:
            design = get_design()
            if not design:
                return
            um = design.unitsManager
            cmd = args.command
            inputs = cmd.commandInputs

            sel_input = inputs.itemById('lineSel')
            if sel_input.selectionCount == 0:
                if ui:
                    ui.messageBox('Please select a construction line.')
                return
            line = sel_input.selection(0).entity

            flange = inputs.itemById('flange').value
            thk = inputs.itemById('thk').value
            endInset = inputs.itemById('endInset').value
            sideInset = inputs.itemById('sideInset').value
            holeDia = inputs.itemById('holeDia').value
            rootFillet = inputs.itemById('rootFillet').value
            prefix = inputs.itemById('prefix').value

            idx = next_index_for_prefix(prefix)

            geo = line.worldGeometry
            p0 = geo.startPoint
            p1 = geo.endPoint
            cc_len = p0.distanceTo(p1)

            total_len = cc_len + 2 * endInset
            length_mm = um.convert(total_len, um.internalUnits, 'mm')
            flange_mm = um.convert(flange, um.internalUnits, 'mm')
            thk_mm = um.convert(thk, um.internalUnits, 'mm')

            name = f"{prefix}{idx} {int(round(length_mm))} {int(round(flange_mm))}x{int(round(thk_mm))}"

            create_ea(line, flange, thk, endInset, sideInset, holeDia, rootFillet, name)
        except:
            if ui:
                ui.messageBox(
                    'EA2HolesExecuteHandler failed:\n{}'.format(
                        traceback.format_exc()
                    )
                )

# ------------------------------------------------------------
# RHS command handlers
# ------------------------------------------------------------

class RHSCreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self):
        super().__init__()

    def notify(self, args):
        global ui, handlers
        try:
            cmd = args.command
            cmd.isExecutedWhenPreEmpted = False
            inputs = cmd.commandInputs

            sel = inputs.addSelectionInput(
                'lineSel',
                'Construction Line',
                'Select a construction line'
            )
            sel.addSelectionFilter('SketchLines')
            sel.setSelectionLimits(1, 1)

            inputs.addValueInput(
                'w', 'Width', 'mm',
                adsk.core.ValueInput.createByString('100 mm')
            )
            inputs.addValueInput(
                'd', 'Depth', 'mm',
                adsk.core.ValueInput.createByString('50 mm')
            )
            inputs.addValueInput(
                't', 'Thickness', 'mm',
                adsk.core.ValueInput.createByString('3 mm')
            )

            inputs.addStringValueInput('prefix', 'Name Prefix', 'C')
            preview = inputs.addStringValueInput('namePreview', 'Next Name', '')
            preview.isReadOnly = True

            ic = RHSInputChangedHandler()
            cmd.inputChanged.add(ic)
            handlers.append(ic)

            ex = RHSExecuteHandler()
            cmd.execute.add(ex)
            handlers.append(ex)

        except:
            if ui:
                ui.messageBox(
                    'RHSCreatedHandler failed:\n{}'.format(
                        traceback.format_exc()
                    )
                )


class RHSInputChangedHandler(adsk.core.InputChangedEventHandler):
    def __init__(self):
        super().__init__()

    def notify(self, args):
        try:
            inputs = args.inputs
            prefix = inputs.itemById('prefix').value
            idx = next_index_for_prefix(prefix)
            inputs.itemById('namePreview').value = f"{prefix}{idx}"
        except:
            pass


class RHSExecuteHandler(adsk.core.CommandEventHandler):
    def __init__(self):
        super().__init__()

    def notify(self, args):
        global ui
        try:
            design = get_design()
            if not design:
                return
            um = design.unitsManager
            cmd = args.command
            inputs = cmd.commandInputs

            sel_input = inputs.itemById('lineSel')
            if sel_input.selectionCount == 0:
                if ui:
                    ui.messageBox('Please select a construction line.')
                return
            line = sel_input.selection(0).entity

            w = inputs.itemById('w').value
            d = inputs.itemById('d').value
            t = inputs.itemById('t').value
            prefix = inputs.itemById('prefix').value

            idx = next_index_for_prefix(prefix)

            geo = line.worldGeometry
            p0 = geo.startPoint
            p1 = geo.endPoint
            length = p0.distanceTo(p1)

            length_mm = um.convert(length, um.internalUnits, 'mm')
            w_mm = um.convert(w, um.internalUnits, 'mm')
            d_mm = um.convert(d, um.internalUnits, 'mm')
            t_mm = um.convert(t, um.internalUnits, 'mm')

            name = f"{prefix}{idx} {int(round(length_mm))} {int(round(w_mm))}x{int(round(d_mm))}x{int(round(t_mm))}"

            create_rhs(line, w, d, t, name)
        except:
            if ui:
                ui.messageBox(
                    'RHSExecuteHandler failed:\n{}'.format(
                        traceback.format_exc()
                    )
                )

# ------------------------------------------------------------
# Geometry creation
# ------------------------------------------------------------

def create_ea(line, flange, thk, endInset, sideInset, holeDia, rootFillet, comp_name):
    global app, ui
    try:
        design = get_design()
        if not design:
            return
        root = design.rootComponent

        # New component at origin
        occ = root.occurrences.addNewComponent(adsk.core.Matrix3D.create())
        # pre-emptively unground in case Fusion flags first occurrence
        occ.isGrounded = False
        comp = occ.component
        comp.name = comp_name

        sketches = comp.sketches
        extrudes = comp.features.extrudeFeatures

        # L-profile in XY plane, origin at heel
        xy = comp.xYConstructionPlane
        sk = sketches.add(xy)
        sl = sk.sketchCurves.sketchLines

        A = adsk.core.Point3D.create(0, 0, 0)
        B = adsk.core.Point3D.create(flange, 0, 0)
        C = adsk.core.Point3D.create(flange, thk, 0)
        D = adsk.core.Point3D.create(thk, thk, 0)
        E = adsk.core.Point3D.create(thk, flange, 0)
        F = adsk.core.Point3D.create(0, flange, 0)

        sl.addByTwoPoints(A, B)
        sl.addByTwoPoints(B, C)
        sl.addByTwoPoints(C, D)
        sl.addByTwoPoints(D, E)
        sl.addByTwoPoints(E, F)
        sl.addByTwoPoints(F, A)

        prof = sk.profiles.item(0)

        # Symmetric extrude along local Z (length axis)
        geo = line.worldGeometry
        p0 = geo.startPoint
        p1 = geo.endPoint
        cc_len = p0.distanceTo(p1)
        total_len = cc_len + 2 * endInset
        half_len = total_len / 2.0

        ext_in = extrudes.createInput(
            prof,
            adsk.fusion.FeatureOperations.NewBodyFeatureOperation
        )
        ext_in.setSymmetricExtent(
            adsk.core.ValueInput.createByReal(half_len),
            True
        )
        extrudes.add(ext_in)

        # Align EA with selected construction line, centered
        orient_occurrence_to_line_center(occ, line)

        # Ensure not grounded after transform as well
        occ.isGrounded = False

    except:
        if ui:
            ui.messageBox('create_ea failed:\n{}'.format(traceback.format_exc()))


def create_rhs(line, w, d, t, comp_name):
    global app, ui
    try:
        design = get_design()
        if not design:
            return
        root = design.rootComponent

        occ = root.occurrences.addNewComponent(adsk.core.Matrix3D.create())
        occ.isGrounded = False
        comp = occ.component
        comp.name = comp_name

        sketches = comp.sketches
        extrudes = comp.features.extrudeFeatures

        # Rectangular hollow section in XY plane, length along Z
        xy = comp.xYConstructionPlane
        sk = sketches.add(xy)
        sl = sk.sketchCurves.sketchLines

        p1 = adsk.core.Point3D.create(-w / 2, -d / 2, 0)
        p2 = adsk.core.Point3D.create(w / 2, d / 2, 0)
        outer = [
            adsk.core.Point3D.create(p1.x, p1.y, 0),
            adsk.core.Point3D.create(p2.x, p1.y, 0),
            adsk.core.Point3D.create(p2.x, p2.y, 0),
            adsk.core.Point3D.create(p1.x, p2.y, 0)
        ]
        for i in range(4):
            sl.addByTwoPoints(outer[i], outer[(i + 1) % 4])

        i1 = adsk.core.Point3D.create(-w / 2 + t, -d / 2 + t, 0)
        i2 = adsk.core.Point3D.create(w / 2 - t, d / 2 - t, 0)
        inner = [
            adsk.core.Point3D.create(i1.x, i1.y, 0),
            adsk.core.Point3D.create(i2.x, i1.y, 0),
            adsk.core.Point3D.create(i2.x, i2.y, 0),
            adsk.core.Point3D.create(i1.x, i2.y, 0)
        ]
        for i in range(4):
            sl.addByTwoPoints(inner[i], inner[(i + 1) % 4])

        prof = sk.profiles.item(0)

        geo = line.worldGeometry
        p0 = geo.startPoint
        p1 = geo.endPoint
        length = p0.distanceTo(p1)
        half_len = length / 2.0

        ext_in = extrudes.createInput(
            prof,
            adsk.fusion.FeatureOperations.NewBodyFeatureOperation
        )
        ext_in.setSymmetricExtent(
            adsk.core.ValueInput.createByReal(half_len),
            True
        )
        extrudes.add(ext_in)

        orient_occurrence_to_line_center(occ, line)

        occ.isGrounded = False

    except:
        if ui:
            ui.messageBox('create_rhs failed:\n{}'.format(traceback.format_exc()))

# ------------------------------------------------------------
# Add-in run/stop
# ------------------------------------------------------------

def run(context):
    global app, ui, handlers
    try:
        app = adsk.core.Application.get()
        if not app:
            return
        ui = app.userInterface
        cmd_defs = ui.commandDefinitions

        ea_cmd_def = cmd_defs.itemById('pt_ea2holes')
        if not ea_cmd_def:
            ea_cmd_def = cmd_defs.addButtonDefinition(
                'pt_ea2holes',
                'EA - 2 Holes',
                'Create an Equal Angle with 2 holes along a selected construction line.',
                'Resources'
            )
        ea_created = EA2HolesCreatedHandler()
        ea_cmd_def.commandCreated.add(ea_created)
        handlers.append(ea_created)

        rhs_cmd_def = cmd_defs.itemById('pt_rhs')
        if not rhs_cmd_def:
            rhs_cmd_def = cmd_defs.addButtonDefinition(
                'pt_rhs',
                'RHS/SHS Member',
                'Create a RHS/SHS member along a selected construction line.',
                'Resources'
            )
        rhs_created = RHSCreatedHandler()
        rhs_cmd_def.commandCreated.add(rhs_created)
        handlers.append(rhs_created)

        panel = ui.allToolbarPanels.itemById('SolidCreatePanel')
        if panel:
            if not panel.controls.itemById('pt_ea2holes'):
                panel.controls.addCommand(ea_cmd_def)
            if not panel.controls.itemById('pt_rhs'):
                panel.controls.addCommand(rhs_cmd_def)

    except:
        if ui:
            ui.messageBox(
                'Phil_Tools_AddIn.run failed:\n{}'.format(
                    traceback.format_exc()
                )
            )


def stop(context):
    global ui
    try:
        app_local = adsk.core.Application.get()
        if not app_local:
            return
        ui = app_local.userInterface
        panel = ui.allToolbarPanels.itemById('SolidCreatePanel')
        if panel:
            for cid in ['pt_ea2holes', 'pt_rhs']:
                ctrl = panel.controls.itemById(cid)
                if ctrl:
                    ctrl.deleteMe()
        cmd_defs = ui.commandDefinitions
        for cid in ['pt_ea2holes', 'pt_rhs']:
            cdef = cmd_defs.itemById(cid)
            if cdef:
                cdef.deleteMe()
    except:
        if ui:
            ui.messageBox(
                'Phil_Tools_AddIn.stop failed:\n{}'.format(
                    traceback.format_exc()
                )
            )
