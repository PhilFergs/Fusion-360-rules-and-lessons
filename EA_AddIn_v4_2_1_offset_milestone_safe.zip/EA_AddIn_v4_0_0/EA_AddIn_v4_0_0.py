# EA_AddIn_v4_0_0.py
# Modular EA Add-In v4.0.x – entry point.

import adsk.core, adsk.fusion, traceback
import os, sys

# Ensure this add-in folder is on sys.path
this_dir = os.path.dirname(__file__)
if this_dir and this_dir not in sys.path:
    sys.path.append(this_dir)

import EA_Main

_app = None
_ui = None


def run(context):
    """Fusion 360 entry point for add-in start."""
    global _app, _ui
    _app = adsk.core.Application.get()
    if not _app:
        return

    _ui = _app.userInterface
    try:
        EA_Main.startup(_app, _ui)
    except:
        if _ui:
            _ui.messageBox('Error in EA_AddIn_v4_0_0.run():\n' + traceback.format_exc())


def stop(context):
    """Fusion 360 entry point for add-in stop."""
    global _app, _ui
    try:
        EA_Main.shutdown()
    except:
        if _ui:
            _ui.messageBox('Error in EA_AddIn_v4_0_0.stop():\n' + traceback.format_exc())
