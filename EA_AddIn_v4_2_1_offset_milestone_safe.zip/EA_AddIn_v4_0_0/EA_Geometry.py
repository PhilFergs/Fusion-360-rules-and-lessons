# EA_Geometry.py
# EA geometry creation for EA Add-In v4.0.x.
#
# This module is a simplified port of the stable EA-Sketchline-Generation
# script v3.1.1. It keeps the *same* geometric conventions and orientation
# logic, but removes the interactive R/A/AA/S/C loop.
#
# Behaviour:
#   - For each selected sketch line:
#       * Treat line length as hole-centre to hole-centre distance.
#       * Place an EA whose gauge leg outer face contains the line of
#         hole centres.
#       * Apply default fillet and hole pattern exactly as v3.1.1.
#       * Orientation angle is fixed at 0° for now (no interactive rotate).
#
#   - Components are created as separate occurrences under the root,
#     named:  EA<index>-<CCmm>mm-<flange>x<flange>x<thickness>
#
# NOTE:
#   - All input parameters are expected in *internal* Fusion units (cm),
#     and are converted back to mm here to reuse the v3.1.1 geometry rules.

import adsk.core
import adsk.fusion
import traceback
import math

# ========= DEFAULT PARAMETERS (mm) =========
DEFAULT_HOLE_DIAMETER_MM   = 13.0
DEFAULT_HOLE_GAUGE_MM      = 25.0
# ==========================================


def build_equal_angles(design: adsk.fusion.Design, lines, params: dict):
    """
    Create EA members along the given sketch lines using v3.1.1 geometry.

    :param design: Active design.
    :param lines: Iterable of adsk.fusion.SketchLine.
    :param params: dict with *internal-unit* (cm) keys:
        - "flange"
        - "thickness"
        - "extra"
    """
    if not design or not lines:
        return

    try:
        um = design.unitsManager
        root = design.rootComponent

        # Convert from internal units (cm) to mm to reuse v3.1.1 helpers.
        flange_cm    = params.get("flange", 7.5)
        thickness_cm = params.get("thickness", 0.6)
        extra_cm     = params.get("extra", 0.0)
        hole_off_cm  = params.get("holeOffset", flange_cm / 2.0)

        flange_mm    = um.convert(flange_cm,    um.internalUnits, "mm")
        thickness_mm = um.convert(thickness_cm, um.internalUnits, "mm")
        extra_mm     = um.convert(extra_cm,     um.internalUnits, "mm")
        hole_g_mm    = um.convert(hole_off_cm,  um.internalUnits, "mm")

        hole_d_mm = DEFAULT_HOLE_DIAMETER_MM
        fillet_mm = thickness_mm  # as in v3.1.1

        next_index = _find_next_ea_index(design)

        for line in lines:
            _create_ea_for_line_simple(
                design, root, line, next_index,
                flange_mm, thickness_mm, extra_mm,
                hole_d_mm, hole_g_mm, fillet_mm
            )
            next_index += 1

    except:
        app, ui = _get_app_ui()
        if ui:
            ui.messageBox(
                "EA_Geometry.build_equal_angles() error:\n" +
                traceback.format_exc()
            )


# ================================================================
#  HELPERS: APP / UI
# ================================================================
def _get_app_ui():
    app = adsk.core.Application.get()
    ui = app.userInterface if app else None
    return app, ui


# ================================================================
#  HELPERS: EA INDEX
# ================================================================
def _find_next_ea_index(design: adsk.fusion.Design) -> int:
    max_index = 0
    for comp in design.allComponents:
        name = comp.name
        if not name.startswith("EA"):
            continue

        digits = ""
        for ch in name[2:]:
            if ch.isdigit():
                digits += ch
            else:
                break

        if digits:
            try:
                n = int(digits)
                if n > max_index:
                    max_index = n
            except:
                pass
    return max_index + 1


# ================================================================
#  ORIENTATION MATRIX (ALIGN HOLE LINE TO SKETCH LINE)
# ================================================================
def _create_orientation_matrix(line_mid, x_base, y_axis, z_base,
                               angle_deg, hole_g_u):
    """
    Create transform such that:
      • Local Y-axis = sketch line direction.
      • Local X/Z define EA cross-section orientation, rotated by angle_deg.
      • Local point (X = hole_g_u, Y = 0, Z = 0) maps to 'line_mid'.
    """
    angle = math.radians(angle_deg)
    c = math.cos(angle)
    s = math.sin(angle)

    # Rotate X/Z around Y
    x_rot = adsk.core.Vector3D.create(
        x_base.x * c + z_base.x * s,
        x_base.y * c + z_base.y * s,
        x_base.z * c + z_base.z * s
    )
    z_rot = adsk.core.Vector3D.create(
        -x_base.x * s + z_base.x * c,
        -x_base.y * s + z_base.y * c,
        -x_base.z * s + z_base.z * c
    )
    x_rot.normalize()
    z_rot.normalize()

    # Set origin so hole centre line lies on the sketch line midpoint
    origin = adsk.core.Point3D.create(
        line_mid.x - x_rot.x * hole_g_u,
        line_mid.y - x_rot.y * hole_g_u,
        line_mid.z - x_rot.z * hole_g_u
    )

    m = adsk.core.Matrix3D.create()
    m.setWithCoordinateSystem(origin, x_rot, y_axis, z_rot)
    return m


# ================================================================
#  CREATE EA FOR ONE SELECTED SKETCH LINE (NON-INTERACTIVE)
# ================================================================
def _create_ea_for_line_simple(design, root, sk_line,
                               ea_index,
                               flange_mm, thickness_mm, extra_mm,
                               hole_d_mm, hole_g_mm, fillet_mm):

    um = design.unitsManager

    # World-space endpoints
    sp = sk_line.startSketchPoint.worldGeometry
    ep = sk_line.endSketchPoint.worldGeometry

    cc_len = sp.distanceTo(ep)
    if cc_len <= 0:
        return

    # Midpoint of sketch line (world coords)
    mid = adsk.core.Point3D.create(
        (sp.x + ep.x) / 2.0,
        (sp.y + ep.y) / 2.0,
        (sp.z + ep.z) / 2.0
    )

    # Y-axis (EA length direction)
    y_axis = adsk.core.Vector3D.create(ep.x - sp.x, ep.y - sp.y, ep.z - sp.z)
    y_axis.normalize()

    # Base X/Z (perpendicular frame)
    temp = adsk.core.Vector3D.create(1, 0, 0)
    if abs(temp.dotProduct(y_axis)) > 0.99:
        temp = adsk.core.Vector3D.create(0, 1, 0)

    x_base = y_axis.crossProduct(temp)
    x_base.normalize()
    z_base = x_base.crossProduct(y_axis)
    z_base.normalize()

    # Hole gauge (internal units)
    hole_g_u = um.convert(hole_g_mm, "mm", um.internalUnits)

    # Use 0° orientation for now (same as initial orientation in v3.1.1)
    initial_angle = 0.0

    # Build initial transform
    mat = _create_orientation_matrix(mid, x_base, y_axis, z_base,
                                     initial_angle, hole_g_u)
    occs = root.occurrences
    occ = occs.addNewComponent(mat)
    comp = occ.component

    # Name component as in v3.1.1
    cc_mm = um.convert(cc_len, um.internalUnits, "mm")
    comp.name = (
        f"EA{ea_index}-{int(round(cc_mm))}mm-"
        f"{int(round(flange_mm))}x{int(round(flange_mm))}x{int(round(thickness_mm))}"
    )

    # Build geometry (EA body, fillet, holes)
    body = _build_ea_geometry(
        design, comp, cc_len,
        flange_mm, thickness_mm, extra_mm,
        hole_d_mm, hole_g_mm, fillet_mm
    )

    _apply_steel_material(comp, body)
    _apply_steel_color(body)

    # Try to refresh viewport
    app, _ = _get_app_ui()
    try:
        app.activeViewport.refresh()
    except:
        pass


# ================================================================
#  GEOMETRY CREATION (EXTRUSIONS, HOLES, FILLET)
# ================================================================
def _build_ea_geometry(design, comp, cc_len,
                       flange_mm, thickness_mm, extra_mm,
                       hole_d_mm, hole_g_mm, fillet_r_mm):

    um = design.unitsManager
    sketches = comp.sketches
    extrudes = comp.features.extrudeFeatures

    flange_u = um.convert(flange_mm,    "mm", um.internalUnits)
    thk_u    = um.convert(thickness_mm, "mm", um.internalUnits)
    extra_u  = um.convert(extra_mm,     "mm", um.internalUnits)
    hole_d_u = um.convert(hole_d_mm,    "mm", um.internalUnits)
    hole_g_u = um.convert(hole_g_mm,    "mm", um.internalUnits)
    fil_u    = um.convert(fillet_r_mm,  "mm", um.internalUnits)

    length_total = cc_len + 2 * extra_u

    # ------------------ L-Section Sketch ------------------
    xz = comp.xZConstructionPlane
    sk = sketches.add(xz)
    sl = sk.sketchCurves.sketchLines

    A = adsk.core.Point3D.create(0,         0,        0)
    B = adsk.core.Point3D.create(flange_u,  0,        0)
    C = adsk.core.Point3D.create(flange_u,  thk_u,    0)
    D = adsk.core.Point3D.create(thk_u,     thk_u,    0)
    E = adsk.core.Point3D.create(thk_u,     flange_u, 0)
    F = adsk.core.Point3D.create(0,         flange_u, 0)

    sl.addByTwoPoints(A, B)
    sl.addByTwoPoints(B, C)
    sl.addByTwoPoints(C, D)
    sl.addByTwoPoints(D, E)
    sl.addByTwoPoints(E, F)
    sl.addByTwoPoints(F, A)

    prof = sk.profiles.item(0)

    # ---------- Extrude L-profile symmetrically along Y ----------
    ext_in = extrudes.createInput(
        prof,
        adsk.fusion.FeatureOperations.NewBodyFeatureOperation
    )
    ext_in.setSymmetricExtent(
        adsk.core.ValueInput.createByReal(length_total),
        True
    )
    ext = extrudes.add(ext_in)
    body = ext.bodies.item(0)

    # ---------- Apply Internal Fillet ----------
    _apply_fillet(comp, body, thk_u, fil_u)

    # ---------- Cut Holes Through the EA ----------
    _cut_ea_holes(comp, body, cc_len, hole_d_u, hole_g_u, flange_u)

    return body


# ================================================================
#  HOLE CREATION
# ================================================================
def _cut_ea_holes(comp, body, cc_len, hole_d_u, hole_g_u, flange_u):

    sketches = comp.sketches
    extrudes = comp.features.extrudeFeatures

    xy = comp.xYConstructionPlane
    sk = sketches.add(xy)
    circ = sk.sketchCurves.sketchCircles

    half = cc_len / 2.0
    radius = hole_d_u / 2.0

    circ.addByCenterRadius(adsk.core.Point3D.create(hole_g_u, -half, 0), radius)
    circ.addByCenterRadius(adsk.core.Point3D.create(hole_g_u,  half, 0), radius)

    pc = adsk.core.ObjectCollection.create()
    for i in range(sk.profiles.count):
        pc.add(sk.profiles.item(i))

    cut_in = extrudes.createInput(
        pc,
        adsk.fusion.FeatureOperations.CutFeatureOperation
    )
    cut_in.participantBodies = [body]

    cut_in.setSymmetricExtent(
        adsk.core.ValueInput.createByReal(flange_u * 2.0),
        True
    )
    extrudes.add(cut_in)


# ================================================================
#  INTERNAL ROOT FILLET
# ================================================================
def _apply_fillet(comp, body, thk_u, rad_u):

    fillets = comp.features.filletFeatures

    target_x = thk_u
    target_z = -thk_u
    tol_pos = max(thk_u * 0.1, 0.0005)
    tol_dir = 1e-6

    # Identify closest vertex to the ideal inside corner
    root_v = None
    best = 1e9

    for v in body.vertices:
        p = v.geometry
        d2 = (p.x - target_x) ** 2 + (p.z - target_z) ** 2
        if d2 < best:
            best = d2
            root_v = v

    if not root_v or best > tol_pos ** 2:
        return

    edges = adsk.core.ObjectCollection.create()
    for e in root_v.edges:
        sv = e.startVertex.geometry
        ev = e.endVertex.geometry

        vertical = (
            abs(sv.x - ev.x) < tol_dir and
            abs(sv.z - ev.z) < tol_dir and
            abs(sv.y - ev.y) > tol_dir
        )
        corner = (
            abs(sv.x - target_x) < tol_pos and
            abs(sv.z - target_z) < tol_pos
        )
        if vertical and corner:
            edges.add(e)

    if edges.count == 0:
        return

    fi = fillets.createInput()
    rad = adsk.core.ValueInput.createByReal(rad_u)

    if hasattr(fi, "edgeSets"):
        fi.edgeSets.addConstantRadiusEdgeSet(edges, rad, True)
    else:
        fi.addConstantRadiusEdgeSet(edges, rad, True)

    fillets.add(fi)


# ================================================================
#  MATERIAL + APPEARANCE
# ================================================================
def _apply_steel_material(comp, body):
    app, _ = _get_app_ui()
    if not app:
        return
    try:
        mats = app.materialLibraries.itemByName("Fusion 360 Material Library")
        steel = mats.materials.itemByName("Steel - Mild")
        if steel:
            body.material = steel
    except:
        pass


def _apply_steel_color(body):
    app, _ = _get_app_ui()
    if not app:
        return
    try:
        design = adsk.fusion.Design.cast(app.activeProduct)
        apps = design.appearances

        app_appear = apps.itemByName("EA Steel Color")
        if not app_appear:
            lib = app.materialLibraries.item(0)
            app_appear = apps.addByColor(
                "EA Steel Color",
                lib,
                adsk.core.Color.create(40, 60, 85)
            )
        body.appearance = app_appear
    except:
        pass
