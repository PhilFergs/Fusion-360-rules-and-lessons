# EA_UI.py
# v4.0.5 baseline + separate EA Rotate tool
# Stage 1c: Auto-detect axis using hole centers (circular edges) if possible,
#           otherwise fall back to longest linear edge.

import adsk.core
import adsk.fusion
import traceback
import math

import EA_State  # kept for future extensions
import EA_Geometry

_app = None
_ui = None
_handlers = []


# ================================================================
# Register / Unregister (called from EA_Main)
# ================================================================
def register_commands(app, ui):
    """Create the Generate and Rotate commands and add them to the Add-Ins panel."""
    global _app, _ui
    _app = app
    _ui = ui

    # Generate EA From Lines
    gen_def = ui.commandDefinitions.itemById("EA_GENERATE")
    if not gen_def:
        gen_def = ui.commandDefinitions.addButtonDefinition(
            "EA_GENERATE",
            "Generate EA From Lines",
            "Create Equal Angle members along selected sketch lines."
        )

    on_gen_created = GenerateCommandCreated()
    gen_def.commandCreated.add(on_gen_created)
    _handlers.append(on_gen_created)

    # Rotate EA 90° (separate tool)
    rot_def = ui.commandDefinitions.itemById("EA_ROTATE_90")
    if not rot_def:
        rot_def = ui.commandDefinitions.addButtonDefinition(
            "EA_ROTATE_90",
            "Rotate EA 90°",
            "Rotate selected EA components 90° around an axis.\n"
            "If no axis is selected, the tool auto-detects one from the EA geometry."
        )

    on_rot_created = RotateCommandCreated()
    rot_def.commandCreated.add(on_rot_created)
    _handlers.append(on_rot_created)

    # Put both commands in the Solid > Scripts and Add-Ins panel
    ws = ui.workspaces.itemById("FusionSolidEnvironment")
    panel = ws.toolbarPanels.itemById("SolidScriptsAddinsPanel")
    if panel:
        if not panel.controls.itemById("EA_GENERATE"):
            panel.controls.addCommand(gen_def)
        if not panel.controls.itemById("EA_ROTATE_90"):
            panel.controls.addCommand(rot_def)


def unregister_commands():
    global _ui
    if not _ui:
        return

    try:
        ws = _ui.workspaces.itemById("FusionSolidEnvironment")
        panel = ws.toolbarPanels.itemById("SolidScriptsAddinsPanel")
        if panel:
            ctrl = panel.controls.itemById("EA_GENERATE")
            if ctrl:
                ctrl.deleteMe()
            ctrl = panel.controls.itemById("EA_ROTATE_90")
            if ctrl:
                ctrl.deleteMe()
    except:
        pass

    # Delete command definitions
    try:
        gen_def = _ui.commandDefinitions.itemById("EA_GENERATE")
        if gen_def:
            gen_def.deleteMe()
    except:
        pass

    try:
        rot_def = _ui.commandDefinitions.itemById("EA_ROTATE_90")
        if rot_def:
            rot_def.deleteMe()
    except:
        pass


# ================================================================
# Generate EA From Lines - UI
# ================================================================
class GenerateCommandCreated(adsk.core.CommandCreatedEventHandler):
    def notify(self, args: adsk.core.CommandCreatedEventArgs):
        try:
            cmd = args.command
            inputs = cmd.commandInputs

            sel = inputs.addSelectionInput(
                "ea_lines",
                "Select Lines",
                "Select sketch lines for EA creation."
            )
            sel.addSelectionFilter("SketchLines")
            sel.setSelectionLimits(1, 0)

            # Defaults in mm (internal units = cm)
            flange_default = 5.0      # 50 mm
            thick_default = 0.3       # 3 mm
            hole_default = 2.5        # 25 mm
            extra_default = 2.0       # 20 mm

            inputs.addValueInput(
                "flange",
                "Flange (mm)",
                "mm",
                adsk.core.ValueInput.createByReal(flange_default)
            )
            inputs.addValueInput(
                "thickness",
                "Thickness (mm)",
                "mm",
                adsk.core.ValueInput.createByReal(thick_default)
            )
            inputs.addValueInput(
                "holeOffset",
                "Hole Offset (mm)",
                "mm",
                adsk.core.ValueInput.createByReal(hole_default)
            )
            inputs.addValueInput(
                "extra",
                "Extra Length (mm)",
                "mm",
                adsk.core.ValueInput.createByReal(extra_default)
            )

            on_exec = GenerateCommandExecute()
            cmd.execute.add(on_exec)
            _handlers.append(on_exec)

            on_input = GenerateInputChanged()
            cmd.inputChanged.add(on_input)
            _handlers.append(on_input)

        except:
            _ui.messageBox("Error in GenerateCommandCreated:\n" + traceback.format_exc())


class GenerateInputChanged(adsk.core.InputChangedEventHandler):
    def notify(self, args: adsk.core.InputChangedEventArgs):
        try:
            inp = args.input
            cmd = args.firingEvent.sender
            if not inp or not cmd:
                return

            # Auto update holeOffset = flange/2
            if inp.id == "flange":
                ci = cmd.commandInputs
                flange_val = ci.itemById("flange").value
                hole_ci = adsk.core.ValueCommandInput.cast(ci.itemById("holeOffset"))
                if hole_ci:
                    hole_ci.value = flange_val / 2.0

        except:
            _ui.messageBox("Error in GenerateInputChanged:\n" + traceback.format_exc())


class GenerateCommandExecute(adsk.core.CommandEventHandler):
    def notify(self, args: adsk.core.CommandEventArgs):
        try:
            cmd = args.command
            inputs = cmd.commandInputs

            sel = adsk.core.SelectionCommandInput.cast(inputs.itemById("ea_lines"))
            if not sel or sel.selectionCount == 0:
                _ui.messageBox("Please select at least one sketch line.")
                return

            lines = [sel.selection(i).entity for i in range(sel.selectionCount)]

            design = _get_design()
            if not design:
                _ui.messageBox("No active design.")
                return

            params = {
                "flange": inputs.itemById("flange").value,
                "thickness": inputs.itemById("thickness").value,
                "holeOffset": inputs.itemById("holeOffset").value,
                "extra": inputs.itemById("extra").value
            }

            # Use existing geometry builder: no orientation logic here.
            EA_Geometry.build_equal_angles(design, lines, params)

        except:
            _ui.messageBox("Error in GenerateCommandExecute:\n" + traceback.format_exc())


# ================================================================
# Rotate EA 90° - UI (axis optional with improved auto-detect)
# ================================================================
class RotateCommandCreated(adsk.core.CommandCreatedEventHandler):
    def notify(self, args: adsk.core.CommandCreatedEventArgs):
        try:
            cmd = args.command
            inputs = cmd.commandInputs

            occ_sel = inputs.addSelectionInput(
                "ea_occurrences",
                "EA Components",
                "Select EA occurrences to rotate."
            )
            occ_sel.addSelectionFilter("Occurrences")
            occ_sel.setSelectionLimits(1, 0)

            axis_sel = inputs.addSelectionInput(
                "ea_axis",
                "Axis (optional)",
                "Select a sketch line or linear edge for the rotation axis, "
                "or leave empty to auto-detect from the EA's holes or longest edge."
            )
            axis_sel.addSelectionFilter("SketchLines")
            axis_sel.addSelectionFilter("LinearEdges")
            axis_sel.setSelectionLimits(0, 1)  # 0 or 1 (optional)

            on_exec = RotateCommandExecute()
            cmd.execute.add(on_exec)
            _handlers.append(on_exec)

        except:
            _ui.messageBox("Error in RotateCommandCreated:\n" + traceback.format_exc())


class RotateCommandExecute(adsk.core.CommandEventHandler):
    def notify(self, args: adsk.core.CommandEventArgs):
        try:
            cmd = args.command
            inputs = cmd.commandInputs

            occ_sel = adsk.core.SelectionCommandInput.cast(inputs.itemById("ea_occurrences"))
            axis_sel = adsk.core.SelectionCommandInput.cast(inputs.itemById("ea_axis"))

            if not occ_sel or occ_sel.selectionCount == 0:
                _ui.messageBox("Please select at least one EA occurrence.")
                return

            design = _get_design()
            if not design:
                _ui.messageBox("No active design.")
                return

            # Determine axis: explicit selection if provided, else auto from first occurrence
            axis_sp = None
            axis_ep = None

            if axis_sel and axis_sel.selectionCount == 1:
                axis_entity = axis_sel.selection(0).entity
                axis_sp, axis_ep = _get_axis_points(axis_entity)
                if not axis_sp or not axis_ep:
                    _ui.messageBox("Could not determine axis from selected entity.")
                    return
            else:
                # Auto-detect axis from first EA occurrence
                first_occ = adsk.fusion.Occurrence.cast(occ_sel.selection(0).entity)
                if not first_occ:
                    _ui.messageBox("Could not auto-detect axis (invalid occurrence).")
                    return
                axis_sp, axis_ep = _get_auto_axis_from_occ(first_occ)
                if not axis_sp or not axis_ep:
                    _ui.messageBox("Could not auto-detect a suitable axis from EA geometry. "
                                   "Please select an axis instead.")
                    return

            mid = adsk.core.Point3D.create(
                (axis_sp.x + axis_ep.x) * 0.5,
                (axis_sp.y + axis_ep.y) * 0.5,
                (axis_sp.z + axis_ep.z) * 0.5
            )
            axis_vec = adsk.core.Vector3D.create(
                axis_ep.x - axis_sp.x,
                axis_ep.y - axis_sp.y,
                axis_ep.z - axis_sp.z
            )
            if axis_vec.length == 0:
                _ui.messageBox("Axis has zero length.")
                return
            axis_vec.normalize()

            angle_rad = math.radians(90.0)
            rot_mat = adsk.core.Matrix3D.create()
            rot_mat.setToRotation(angle_rad, axis_vec, mid)

            root = design.rootComponent
            move_feats = root.features.moveFeatures

            # Rotate each selected occurrence's bodies by 90°
            for i in range(occ_sel.selectionCount):
                occ = adsk.fusion.Occurrence.cast(occ_sel.selection(i).entity)
                if not occ:
                    continue

                ents = adsk.core.ObjectCollection.create()
                for b in occ.bRepBodies:
                    ents.add(b)

                if ents.count == 0:
                    continue

                mv_input = move_feats.createInput(ents, rot_mat)
                move_feats.add(mv_input)

            try:
                _app.activeViewport.refresh()
            except:
                pass

        except:
            _ui.messageBox("Error in RotateCommandExecute:\n" + traceback.format_exc())


# ================================================================
# Helpers
# ================================================================
def _get_axis_points(entity):
    """Return (startPoint, endPoint) in world space for a sketch line or linear edge."""
    try:
        if isinstance(entity, adsk.fusion.SketchLine):
            sp = entity.startSketchPoint.worldGeometry
            ep = entity.endSketchPoint.worldGeometry
            return sp, ep

        edge = adsk.fusion.BRepEdge.cast(entity)
        if edge:
            sp = edge.startVertex.geometry
            ep = edge.endVertex.geometry
            return sp, ep
    except:
        pass
    return None, None


def _get_auto_axis_from_occ(occ):
    """Infer axis from occurrence:

    1) Prefer a line through the centers of circular edges (holes).
    2) If no suitable holes, fall back to longest linear edge.
    """
    try:
        # --- 1) Look for circular edges (holes) ---
        centers = []
        for body in occ.bRepBodies:
            for edge in body.edges:
                circ = adsk.core.Circle3D.cast(edge.geometry)
                if circ:
                    centers.append(circ.center)

        if len(centers) >= 2:
            # Find the two centers that are farthest apart -> end points of hole axis
            max_d2 = -1.0
            sp = None
            ep = None
            for i in range(len(centers)):
                for j in range(i + 1, len(centers)):
                    c1 = centers[i]
                    c2 = centers[j]
                    dx = c2.x - c1.x
                    dy = c2.y - c1.y
                    dz = c2.z - c1.z
                    d2 = dx * dx + dy * dy + dz * dz
                    if d2 > max_d2:
                        max_d2 = d2
                        sp = c1
                        ep = c2
            if sp and ep and max_d2 > 0:
                return sp, ep

        # --- 2) Fallback: longest linear edge ---
        longest_edge = None
        longest_len = 0.0

        for body in occ.bRepBodies:
            for edge in body.edges:
                line = adsk.core.Line3D.cast(edge.geometry)
                if not line:
                    continue
                sv = edge.startVertex.geometry
                ev = edge.endVertex.geometry
                if not sv or not ev:
                    continue
                vec = adsk.core.Vector3D.create(
                    ev.x - sv.x,
                    ev.y - sv.y,
                    ev.z - sv.z
                )
                length = vec.length
                if length > longest_len:
                    longest_len = length
                    longest_edge = edge

        if longest_edge and longest_len > 0:
            sv = longest_edge.startVertex.geometry
            ev = longest_edge.endVertex.geometry
            return sv, ev

        # --- 3) Final fallback: bounding box diagonal ---
        bbox = occ.boundingBox
        if not bbox:
            return None, None
        min_pt = bbox.minPoint
        max_pt = bbox.maxPoint
        sp = adsk.core.Point3D.create(min_pt.x, min_pt.y, min_pt.z)
        ep = adsk.core.Point3D.create(max_pt.x, max_pt.y, max_pt.z)
        return sp, ep

    except:
        return None, None


def _get_design():
    if not _app:
        return None
    return adsk.fusion.Design.cast(_app.activeProduct)
