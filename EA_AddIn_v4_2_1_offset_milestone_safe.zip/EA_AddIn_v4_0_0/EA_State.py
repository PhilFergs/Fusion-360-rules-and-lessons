# EA_State.py
# State machine for EA placement workflow.

# Central state dictionary
_state = {
    "lines": [],
    "params": {},
    "current_index": 0,
    "preview_occ": None,
    "preview_comp": None,
    "accept_all": False,
    "global_rotation_deg": 0.0,
}


def reset_state():
    """
    Reset to a clean default state.
    """
    global _state
    _state = {
        "lines": [],
        "params": {},
        "current_index": 0,
        "preview_occ": None,
        "preview_comp": None,
        "accept_all": False,
        "global_rotation_deg": 0.0,
    }


# ---------------------------------------------------------------------
# Initialisation from UI selection
# ---------------------------------------------------------------------

def init_from_selection(lines, params):
    """
    Initialize state from a list of sketch lines and EA parameters.

    :param lines: iterable of sketch lines (or any descriptors you use)
    :param params: dict with keys like:
        - "flange"
        - "thickness"
        - "extra"
        - "holeDia"
        - "gauge"
    """
    reset_state()
    _state["lines"] = list(lines) if lines else []
    _state["params"] = dict(params) if params else {}
    _state["current_index"] = 0
    _state["accept_all"] = False
    _state["global_rotation_deg"] = 0.0


# ---------------------------------------------------------------------
# Basic getters
# ---------------------------------------------------------------------

def get_lines():
    return _state.get("lines", [])


def get_params():
    return _state.get("params", {})


def get_current_index():
    return int(_state.get("current_index", 0))


def set_current_index(idx):
    _state["current_index"] = int(idx)


def has_more():
    """
    Returns True if there are still lines left to process.
    """
    idx = get_current_index()
    return 0 <= idx < len(get_lines())


def get_current_line():
    """
    Return the current line based on current_index, or None if out of range.
    """
    lines = get_lines()
    idx = get_current_index()
    if 0 <= idx < len(lines):
        return lines[idx]
    return None


def advance_to_next():
    """
    Increment the current_index and return the new current line (or None).
    """
    idx = get_current_index() + 1
    set_current_index(idx)
    return get_current_line()


# ---------------------------------------------------------------------
# Preview occurrence / component
# ---------------------------------------------------------------------

def set_preview_occurrence(occ):
    _state["preview_occ"] = occ


def get_preview_occurrence():
    return _state.get("preview_occ")


def set_preview_component(comp):
    _state["preview_comp"] = comp


def get_preview_component():
    return _state.get("preview_comp")


def clear_preview():
    _state["preview_occ"] = None
    _state["preview_comp"] = None


# ---------------------------------------------------------------------
# Accept-all and global rotation
# ---------------------------------------------------------------------

def is_accept_all():
    return bool(_state.get("accept_all", False))


def enable_accept_all(rotation_deg):
    _state["accept_all"] = True
    _state["global_rotation_deg"] = float(rotation_deg)


def disable_accept_all():
    _state["accept_all"] = False
    _state["global_rotation_deg"] = 0.0


def get_global_rotation_deg():
    return float(_state.get("global_rotation_deg", 0.0))


def set_global_rotation_deg(deg):
    _state["global_rotation_deg"] = float(deg)


def increment_global_rotation(step_deg=90.0):
    current = float(_state.get("global_rotation_deg", 0.0))
    _state["global_rotation_deg"] = current + float(step_deg)
    return _state["global_rotation_deg"]
