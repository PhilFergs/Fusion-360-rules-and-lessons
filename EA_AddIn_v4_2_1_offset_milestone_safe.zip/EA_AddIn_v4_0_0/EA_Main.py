# EA_Main.py
# Core startup / shutdown and high-level orchestration.

import adsk.core, adsk.fusion, traceback
import EA_UI

_app = None
_ui = None


def startup(app, ui):
    global _app, _ui
    _app, _ui = app, ui
    try:
        EA_UI.register_commands(app, ui)
        # Optional: small toast only on first load; keep message minimal
        # _ui.messageBox("EA_AddIn v4.0.3 geometry scaffold loaded. (EA_Main)")
    except:
        if _ui:
            _ui.messageBox("Error in EA_Main.startup():\n" + traceback.format_exc())


def shutdown():
    global _ui
    try:
        EA_UI.unregister_commands()
        # if _ui:
        #     _ui.messageBox("EA_AddIn v4.0.3 geometry scaffold stopped. (EA_Main)")
    except:
        if _ui:
            _ui.messageBox("Error in EA_Main.shutdown():\n" + traceback.format_exc())
