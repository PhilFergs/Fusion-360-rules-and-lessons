@echo off
setlocal
set "PKGROOT=%~dp0."
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install_fusion_addins.ps1" -PackageRoot "%PKGROOT%" %*
set EXITCODE=%ERRORLEVEL%
if /I not "%1"=="--quiet" pause
exit /b %EXITCODE%

