import adsk.core, adsk.fusion, traceback, os, math, json
import smg_context as ctx
import smg_logger as logger


CMD_ID = "PhilsDesignTools_StubArms"
CMD_NAME = "Stub Arms To Wall"
CMD_TOOLTIP = "Create stub arm sketch lines from RHS columns to the wall."
RESOURCE_FOLDER = os.path.join(os.path.dirname(__file__), "resources", CMD_ID)
STUB_LINES_COMPONENT_NAME = "Stub arm lines"
STUB_MEMBER_ATTR_GROUP = "PhilsDesignTools"
STUB_MEMBER_ATTR_NAME = "StubMemberType"
STUB_BRACKET_ATTR_NAME = "StubBracketType"
STUB_BRACKET_ANCHOR_ATTR_NAME = "StubBracketAnchor"
STUB_BRACKET_ATTR_MAP_NAME = "StubBracketTypeMap"
STUB_BRACKET_ANCHOR_MAP_NAME = "StubBracketAnchorMap"
BRACKET_SQUARE_TOL_DEG = 3.0
STUB_POINT_DEFAULT_COUNT = 5
STUB_POINT_MIN_MM = 800.0
STUB_POINT_MAX_MM = 1200.0
STUB_BOTTOM_DEFAULT_MM = 200.0
STUB_TOP_DEFAULT_MM = 150.0
STUB_CLEARANCE_DEFAULT_MM = 200.0
STUB_WALL_INSET_DEFAULT_MM = 60.0
STUB_SETTINGS_ATTR_NAME = "StubArmsSettings"

TOL = 1e-6
ANGLE_TOL = 1e-3
DEBUG_STUB_ARMS = False
DEBUG_WALL_MARKERS = False
DEBUG_PROFILE_TEST = False
USE_SKETCH_FALLBACK = True
USE_RAY_FALLBACK = False


class StubArmsExecuteHandler(adsk.core.CommandEventHandler):
    def notify(self, args):
        try:
            _execute(args)
        except:
            logger.log("Stub Arms command failed:\n" + traceback.format_exc())
            ctx.ui().messageBox("Stub Arms command failed:\n" + traceback.format_exc())


class StubArmsCreatedHandler(adsk.core.CommandCreatedEventHandler):
    def notify(self, args):
        try:
            design = adsk.fusion.Design.cast(ctx.app().activeProduct)
            if not design:
                ctx.ui().messageBox("No active design.")
                return
            um = design.unitsManager
            length_units = um.defaultLengthUnits or "mm"

            cmd = args.command
            cmd.isRepeatable = True
            inputs = cmd.commandInputs

            if inputs.itemById("stub_cols"):
                return

            settings = _load_stub_settings(design.rootComponent)
            if DEBUG_STUB_ARMS:
                _dbg(f"Loaded settings: {settings}")

            def safe_float(key, default):
                try:
                    return float(settings.get(key, default))
                except:
                    return float(default)

            try:
                points_default = int(settings.get("points", STUB_POINT_DEFAULT_COUNT))
            except:
                points_default = STUB_POINT_DEFAULT_COUNT
            points_default = max(2, min(20, points_default))

            sel_cols = inputs.addSelectionInput(
                "stub_cols",
                "RHS/SHS column faces",
                "Select a planar face or a column body"
            )
            sel_cols.addSelectionFilter("Faces")
            sel_cols.addSelectionFilter("Bodies")
            sel_cols.addSelectionFilter("Occurrences")
            sel_cols.setSelectionLimits(1, 0)

            sel_wall = inputs.addSelectionInput(
                "stub_wall",
                "Wall faces",
                "Select wall faces or surface bodies"
            )
            sel_wall.addSelectionFilter("Faces")
            sel_wall.addSelectionFilter("Bodies")
            sel_wall.addSelectionFilter("Occurrences")
            sel_wall.setSelectionLimits(1, 0)

            inputs.addIntegerSpinnerCommandInput(
                "stub_points",
                "Connection points",
                2,
                20,
                1,
                points_default
            )

            def v(mm):
                return adsk.core.ValueInput.createByString(f"{mm} mm")

            inputs.addValueInput(
                "stub_min_spacing",
                "Min spacing",
                length_units,
                v(safe_float("min_spacing_mm", STUB_POINT_MIN_MM)),
            )
            inputs.addValueInput(
                "stub_max_spacing",
                "Max spacing",
                length_units,
                v(safe_float("max_spacing_mm", STUB_POINT_MAX_MM)),
            )
            inputs.addValueInput(
                "stub_bottom",
                "Bottom offset",
                length_units,
                v(safe_float("bottom_mm", STUB_BOTTOM_DEFAULT_MM)),
            )
            inputs.addValueInput(
                "stub_top",
                "Top offset",
                length_units,
                v(safe_float("top_mm", STUB_TOP_DEFAULT_MM)),
            )
            inputs.addValueInput(
                "stub_clearance",
                "Wall clearance",
                length_units,
                v(safe_float("clearance_mm", STUB_CLEARANCE_DEFAULT_MM)),
            )
            inputs.addValueInput(
                "stub_wall_inset",
                "Wall inset",
                length_units,
                v(safe_float("wall_inset_mm", STUB_WALL_INSET_DEFAULT_MM)),
            )

            on_exec = StubArmsExecuteHandler()
            cmd.execute.add(on_exec)
            ctx.add_handler(on_exec)
        except:
            logger.log("Stub Arms CommandCreated failed:\n" + traceback.format_exc())
            ctx.ui().messageBox("Stub Arms CommandCreated failed:\n" + traceback.format_exc())


def _dbg(message):
    if DEBUG_STUB_ARMS:
        logger.log(f"{CMD_NAME} DEBUG: {message}")


def _normalise(v):
    out = adsk.core.Vector3D.create(v.x, v.y, v.z)
    if out.length > TOL:
        out.normalize()
    return out


def _canon_dir(v):
    v2 = _normalise(v)
    if v2.x < 0 or (abs(v2.x) < TOL and v2.y < 0) or \
       (abs(v2.x) < TOL and abs(v2.y) < TOL and v2.z < 0):
        v2.scaleBy(-1)
    return v2


def _get_body_center(body):
    try:
        props = body.physicalProperties
        if props:
            com = props.centerOfMass
            if com:
                return com
    except:
        pass

    bb = body.boundingBox
    mp = bb.minPoint
    xp = bb.maxPoint
    return adsk.core.Point3D.create(
        (mp.x + xp.x) * 0.5,
        (mp.y + xp.y) * 0.5,
        (mp.z + xp.z) * 0.5,
    )


def _get_body_axis(body):
    clusters = []
    for e in body.edges:
        line = adsk.core.Line3D.cast(e.geometry)
        if not line:
            continue
        sp = line.startPoint
        ep = line.endPoint
        vec = adsk.core.Vector3D.create(
            ep.x - sp.x,
            ep.y - sp.y,
            ep.z - sp.z,
        )
        length = vec.length
        if length < TOL:
            continue
        d = _canon_dir(vec)

        placed = False
        for c in clusters:
            if c["dir"].crossProduct(d).length < ANGLE_TOL:
                c["tot"] += length
                placed = True
                break
        if not placed:
            clusters.append({"dir": d, "tot": length})

    if not clusters:
        return None

    clusters.sort(key=lambda c: c["tot"], reverse=True)
    return clusters[0]["dir"]


def _axis_endpoints(body, axis):
    center = _get_body_center(body)
    if not center or not axis:
        return None, None, None, None

    min_t = None
    max_t = None
    for v in body.vertices:
        p = v.geometry
        diff = adsk.core.Vector3D.create(
            p.x - center.x,
            p.y - center.y,
            p.z - center.z,
        )
        t = diff.dotProduct(axis)
        if min_t is None:
            min_t = max_t = t
        else:
            min_t = min(min_t, t)
            max_t = max(max_t, t)

    if min_t is None or abs(max_t - min_t) < TOL:
        return None, None, None, None

    bottom = adsk.core.Point3D.create(
        center.x + axis.x * min_t,
        center.y + axis.y * min_t,
        center.z + axis.z * min_t,
    )
    top = adsk.core.Point3D.create(
        center.x + axis.x * max_t,
        center.y + axis.y * max_t,
        center.z + axis.z * max_t,
    )

    # Ensure bottom/top follow world Z so offsets map to "down/up" consistently.
    if bottom.z > top.z:
        bottom, top = top, bottom

    axis_vec = adsk.core.Vector3D.create(
        top.x - bottom.x,
        top.y - bottom.y,
        top.z - bottom.z,
    )
    if axis_vec.length < TOL:
        return None, None, None, None
    axis_vec.normalize()
    length = bottom.distanceTo(top)
    return axis_vec, bottom, top, length


def _resolve_point_spacing(span, desired_count, min_spacing_u, max_spacing_u):
    min_count = max(2, int(math.ceil(span / max_spacing_u)) + 1)
    max_count = max(2, int(math.floor(span / min_spacing_u)) + 1)
    count = desired_count if desired_count and desired_count > 1 else min_count
    adjusted = False
    if count < min_count:
        count = min_count
        adjusted = True
    elif count > max_count:
        count = max_count
        adjusted = True
    spacing = span / float(count - 1) if count > 1 else None
    in_range = spacing is not None and (min_spacing_u - TOL) <= spacing <= (max_spacing_u + TOL)
    return count, spacing, adjusted, min_count, max_count, in_range


def _looks_like_rhs_shs(body, axis_dir):
    if not body or not axis_dir:
        return False
    side_faces = []
    for face in body.faces:
        plane = adsk.core.Plane.cast(face.geometry)
        if not plane:
            continue
        n = plane.normal
        if not n or n.length < TOL:
            continue
        n_vec = adsk.core.Vector3D.create(n.x, n.y, n.z)
        n_vec.normalize()
        if abs(n_vec.dotProduct(axis_dir)) > 0.2:
            continue
        side_faces.append(n_vec)

    if len(side_faces) < 4:
        return False

    clusters = []
    for n_vec in side_faces:
        d = _canon_dir(n_vec)
        placed = False
        for c in clusters:
            if c["dir"].crossProduct(d).length < ANGLE_TOL:
                c["count"] += 1
                placed = True
                break
        if not placed:
            clusters.append({"dir": d, "count": 1})

    return len(clusters) >= 2


def _offset_point(p, d, dist):
    return adsk.core.Point3D.create(
        p.x + d.x * dist,
        p.y + d.y * dist,
        p.z + d.z * dist,
    )


def _get_face_plane(face):
    if not face:
        return None
    try:
        res = face.evaluator.getPlane()
        if isinstance(res, tuple):
            if res[0]:
                return res[1]
        elif res:
            return res
    except:
        pass
    return adsk.core.Plane.cast(face.geometry)


def _get_wall_center_sketch(root, entry, cache):
    if not root or not entry or cache is None:
        return None
    face = entry.get("asm") if isinstance(entry, dict) else entry
    if not face:
        return None
    try:
        key = face.entityToken
    except:
        key = id(face)
    if key in cache:
        return cache[key]
    try:
        sk = root.sketches.add(face)
    except:
        return None
    try:
        sk.name = _next_sketch_name(root, "WallCenter")
    except:
        pass
    try:
        edges = adsk.core.ObjectCollection.create()
        loop_edges = None
        try:
            loops = face.loops
            for li in range(loops.count):
                loop = loops.item(li)
                try:
                    if not loop.isOuter:
                        continue
                except:
                    continue
                try:
                    loop_edges = loop.edges
                except:
                    loop_edges = None
                break
        except:
            loop_edges = None
        if loop_edges:
            for i in range(loop_edges.count):
                edges.add(loop_edges.item(i))
        else:
            for i in range(face.edges.count):
                edges.add(face.edges.item(i))
        proj = sk.project(edges)
        try:
            for i in range(proj.count):
                curve = proj.item(i)
                try:
                    curve.isConstruction = False
                except:
                    pass
                try:
                    curve.isReference = False
                except:
                    pass
                if DEBUG_STUB_ARMS:
                    try:
                        _dbg(
                            f"WallCenter proj curve {i}: "
                            f"construction={getattr(curve, 'isConstruction', None)} "
                            f"reference={getattr(curve, 'isReference', None)}"
                        )
                    except:
                        pass
        except:
            pass
        if DEBUG_STUB_ARMS:
            try:
                _dbg(f"WallCenter profiles={sk.profiles.count}")
            except:
                pass
    except:
        pass
    cache[key] = sk
    return sk


def _disable_sketch_profiles(sketch):
    if not sketch:
        return
    for attr in (
        "areProfilesVisible",
        "isProfilesVisible",
        "areProfilesShown",
        "isProfileShown",
    ):
        try:
            setattr(sketch, attr, False)
        except:
            pass


def _default_stub_settings():
    return {
        "points": STUB_POINT_DEFAULT_COUNT,
        "min_spacing_mm": STUB_POINT_MIN_MM,
        "max_spacing_mm": STUB_POINT_MAX_MM,
        "bottom_mm": STUB_BOTTOM_DEFAULT_MM,
        "top_mm": STUB_TOP_DEFAULT_MM,
        "clearance_mm": STUB_CLEARANCE_DEFAULT_MM,
        "wall_inset_mm": STUB_WALL_INSET_DEFAULT_MM,
    }


def _load_stub_settings(root):
    settings = _default_stub_settings()
    raw = _get_attr_value(root, STUB_MEMBER_ATTR_GROUP, STUB_SETTINGS_ATTR_NAME)
    if not raw:
        return settings
    try:
        data = json.loads(raw)
    except:
        return settings
    if not isinstance(data, dict):
        return settings
    for k in list(settings.keys()):
        if k in data and data[k] is not None:
            settings[k] = data[k]
    return settings


def _save_stub_settings(root, settings):
    if not root or not settings:
        return False
    try:
        payload = json.dumps(settings)
    except:
        return False
    return _set_attr(root, STUB_MEMBER_ATTR_GROUP, STUB_SETTINGS_ATTR_NAME, payload)


def _set_attr(entity, group, name, value):
    if not entity or value is None:
        return False
    try:
        attrs = entity.attributes
    except:
        return False
    if not attrs:
        return False
    try:
        existing = attrs.itemByName(group, name)
        if existing:
            existing.value = str(value)
            return True
    except:
        pass
    try:
        attrs.add(group, name, str(value))
        return True
    except:
        pass
    return False


def _get_attr_value(entity, group, name):
    if not entity or not group or not name:
        return None
    try:
        attrs = entity.attributes
    except:
        return None
    if not attrs:
        return None
    try:
        attr = attrs.itemByName(group, name)
    except:
        return None
    if not attr:
        return None
    try:
        return attr.value
    except:
        return None


def _entity_key(entity):
    if not entity:
        return "none"
    try:
        tok = entity.entityToken
        if tok:
            return tok
    except:
        pass
    return f"id:{id(entity)}"


def _get_attr_map(entity, map_name):
    if not entity or not map_name:
        return {}
    raw = _get_attr_value(entity, STUB_MEMBER_ATTR_GROUP, map_name)
    if not raw:
        return {}
    try:
        data = json.loads(raw)
        if isinstance(data, dict):
            return data
    except:
        pass
    data = {}
    for line in str(raw).splitlines():
        line = line.strip()
        if not line or "=" not in line:
            continue
        key, val = line.split("=", 1)
        data[key] = val
    return data


def _set_attr_map_value(entity, map_name, key, value):
    if not entity or not map_name or not key:
        return False
    data = _get_attr_map(entity, map_name)
    data[key] = str(value)
    payload = json.dumps(data, separators=(",", ":"))
    return _set_attr(entity, STUB_MEMBER_ATTR_GROUP, map_name, payload)


def _tag_stub_line(line, member_type):
    if not line or not member_type:
        return
    _set_attr(line, STUB_MEMBER_ATTR_GROUP, STUB_MEMBER_ATTR_NAME, member_type)
    try:
        native = line.nativeObject
    except:
        native = None
    if native:
        _set_attr(native, STUB_MEMBER_ATTR_GROUP, STUB_MEMBER_ATTR_NAME, member_type)


def _tag_stub_bracket(line, bracket_type, anchor):
    if not line or not bracket_type:
        return
    line_attr_ok = _set_attr(line, STUB_MEMBER_ATTR_GROUP, STUB_BRACKET_ATTR_NAME, bracket_type)
    try:
        native = line.nativeObject
    except:
        native = None
    native_attr_ok = False
    if native:
        native_attr_ok = _set_attr(native, STUB_MEMBER_ATTR_GROUP, STUB_BRACKET_ATTR_NAME, bracket_type)
    line_anchor_ok = False
    native_anchor_ok = False
    if anchor:
        line_anchor_ok = _set_attr(line, STUB_MEMBER_ATTR_GROUP, STUB_BRACKET_ANCHOR_ATTR_NAME, "1")
        if native:
            native_anchor_ok = _set_attr(native, STUB_MEMBER_ATTR_GROUP, STUB_BRACKET_ANCHOR_ATTR_NAME, "1")
    try:
        sk = line.parentSketch
    except:
        sk = None
    comp = None
    if sk:
        try:
            comp = sk.parentComponent
        except:
            comp = None
    map_sk_type = False
    map_sk_anchor = False
    map_comp_type = False
    map_comp_anchor = False
    key = _entity_key(line)
    if sk:
        map_sk_type = _set_attr_map_value(sk, STUB_BRACKET_ATTR_MAP_NAME, key, bracket_type)
        if anchor:
            map_sk_anchor = _set_attr_map_value(sk, STUB_BRACKET_ANCHOR_MAP_NAME, key, "1")
    if comp:
        map_comp_type = _set_attr_map_value(comp, STUB_BRACKET_ATTR_MAP_NAME, key, bracket_type)
        if anchor:
            map_comp_anchor = _set_attr_map_value(comp, STUB_BRACKET_ANCHOR_MAP_NAME, key, "1")
    if native:
        native_key = _entity_key(native)
        if sk:
            _set_attr_map_value(sk, STUB_BRACKET_ATTR_MAP_NAME, native_key, bracket_type)
            if anchor:
                _set_attr_map_value(sk, STUB_BRACKET_ANCHOR_MAP_NAME, native_key, "1")
        if comp:
            _set_attr_map_value(comp, STUB_BRACKET_ATTR_MAP_NAME, native_key, bracket_type)
            if anchor:
                _set_attr_map_value(comp, STUB_BRACKET_ANCHOR_MAP_NAME, native_key, "1")
    if DEBUG_STUB_ARMS:
        line_key = _entity_key(line)
        native_key = _entity_key(native) if native else "none"
        line_attr = _get_attr_value(line, STUB_MEMBER_ATTR_GROUP, STUB_BRACKET_ATTR_NAME)
        line_anchor = _get_attr_value(line, STUB_MEMBER_ATTR_GROUP, STUB_BRACKET_ANCHOR_ATTR_NAME)
        native_attr = (
            _get_attr_value(native, STUB_MEMBER_ATTR_GROUP, STUB_BRACKET_ATTR_NAME)
            if native
            else None
        )
        native_anchor = (
            _get_attr_value(native, STUB_MEMBER_ATTR_GROUP, STUB_BRACKET_ANCHOR_ATTR_NAME)
            if native
            else None
        )
        map_type = _get_attr_value(sk, STUB_MEMBER_ATTR_GROUP, STUB_BRACKET_ATTR_MAP_NAME) if sk else None
        map_anchor = _get_attr_value(sk, STUB_MEMBER_ATTR_GROUP, STUB_BRACKET_ANCHOR_MAP_NAME) if sk else None
        comp_map_type = _get_attr_value(comp, STUB_MEMBER_ATTR_GROUP, STUB_BRACKET_ATTR_MAP_NAME) if comp else None
        comp_map_anchor = _get_attr_value(comp, STUB_MEMBER_ATTR_GROUP, STUB_BRACKET_ANCHOR_MAP_NAME) if comp else None
        logger.log(
            f"{CMD_NAME} DEBUG: bracket tag line={line_key} native={native_key} "
            f"type={bracket_type} anchor={anchor} line_attr={line_attr} "
            f"line_anchor={line_anchor} native_attr={native_attr} "
            f"native_anchor={native_anchor} line_attr_ok={line_attr_ok} "
            f"native_attr_ok={native_attr_ok} line_anchor_ok={line_anchor_ok} "
            f"native_anchor_ok={native_anchor_ok} map_sk_type_ok={map_sk_type} "
            f"map_sk_anchor_ok={map_sk_anchor} map_comp_type_ok={map_comp_type} "
            f"map_comp_anchor_ok={map_comp_anchor} map_sk_present={bool(map_type)} "
            f"map_comp_present={bool(comp_map_type)} map_anchor_present={bool(map_anchor)} "
            f"map_comp_anchor_present={bool(comp_map_anchor)}"
        )


def _angle_deg_between_normals_xy(n1, n2):
    if not n1 or not n2:
        return None
    v1 = adsk.core.Vector3D.create(n1.x, n1.y, 0.0)
    v2 = adsk.core.Vector3D.create(n2.x, n2.y, 0.0)
    if v1.length < TOL or v2.length < TOL:
        return None
    v1.normalize()
    v2.normalize()
    dot = max(-1.0, min(1.0, v1.dotProduct(v2)))
    dot = abs(dot)
    return math.degrees(math.acos(dot))


def _angle_deg_between_vectors_3d(v1, v2):
    if not v1 or not v2:
        return None
    a = adsk.core.Vector3D.create(v1.x, v1.y, v1.z)
    b = adsk.core.Vector3D.create(v2.x, v2.y, v2.z)
    if a.length < TOL or b.length < TOL:
        return None
    a.normalize()
    b.normalize()
    dot = max(-1.0, min(1.0, a.dotProduct(b)))
    dot = abs(dot)
    return math.degrees(math.acos(dot))


def _bracket_type_for_faces(wall_entry, arm_dir, fallback_dir=None):
    if not wall_entry:
        return "swivel"
    wall_face = wall_entry.get("asm") if isinstance(wall_entry, dict) else wall_entry
    wall_plane = _get_face_plane(wall_face)
    if not wall_plane or not wall_plane.normal:
        return "swivel"
    wall_n = wall_plane.normal
    if not wall_n:
        return "swivel"
    angle = None
    if arm_dir:
        angle = _angle_deg_between_normals_xy(arm_dir, wall_n)
    if angle is None and fallback_dir:
        angle = _angle_deg_between_normals_xy(fallback_dir, wall_n)
    if angle is None:
        base_dir = arm_dir if arm_dir else fallback_dir
        angle = _angle_deg_between_vectors_3d(base_dir, wall_n)
    if angle is None:
        return "swivel"
    if angle <= BRACKET_SQUARE_TOL_DEG:
        return "square"
    return "swivel"


def _dist2_2d(a, b):
    dx = a[0] - b[0]
    dy = a[1] - b[1]
    return dx * dx + dy * dy


def _point_on_segment_2d(px, py, ax, ay, bx, by, tol):
    cross = (px - ax) * (by - ay) - (py - ay) * (bx - ax)
    if abs(cross) > tol:
        return False
    dot = (px - ax) * (bx - ax) + (py - ay) * (by - ay)
    if dot < -tol:
        return False
    len_sq = (bx - ax) * (bx - ax) + (by - ay) * (by - ay)
    if dot - len_sq > tol:
        return False
    return True


def _point_in_poly_2d(px, py, poly, tol):
    inside = False
    n = len(poly)
    if n < 3:
        return False
    for i in range(n):
        ax, ay = poly[i]
        bx, by = poly[(i + 1) % n]
        if _point_on_segment_2d(px, py, ax, ay, bx, by, tol):
            return True
        if (ay > py) != (by > py):
            x_int = ax + (py - ay) * (bx - ax) / (by - ay)
            if x_int >= px - tol:
                inside = not inside
    return inside


def _profile_outer_loop_points(profile, tol):
    if not profile:
        return []
    loops = None
    try:
        loops = profile.profileLoops
    except:
        loops = None
    if not loops or loops.count == 0:
        return []
    loop = None
    for li in range(loops.count):
        l = loops.item(li)
        try:
            if l.isOuter:
                loop = l
                break
        except:
            continue
    if not loop:
        loop = loops.item(0)
    try:
        curves = loop.profileCurves
    except:
        return []
    pts = []
    last = None
    tol_sq = tol * tol
    for i in range(curves.count):
        pc = curves.item(i)
        ent = None
        try:
            ent = pc.sketchEntity
        except:
            ent = None
        if not ent:
            continue
        try:
            sp = ent.startSketchPoint.geometry
            ep = ent.endSketchPoint.geometry
        except:
            continue
        s = (sp.x, sp.y)
        e = (ep.x, ep.y)
        if not pts:
            pts.append(s)
            pts.append(e)
            last = e
            continue
        if _dist2_2d(last, s) <= tol_sq:
            pts.append(e)
            last = e
        elif _dist2_2d(last, e) <= tol_sq:
            pts.append(s)
            last = s
        else:
            pts.append(s)
            pts.append(e)
            last = e
    cleaned = []
    for p in pts:
        if not cleaned or _dist2_2d(cleaned[-1], p) > tol_sq:
            cleaned.append(p)
    if len(cleaned) > 1 and _dist2_2d(cleaned[0], cleaned[-1]) <= tol_sq:
        cleaned.pop()
    return cleaned


def _is_point_inside_sketch_profile(sketch, point):
    if not sketch or not point:
        return False
    try:
        p_sk = sketch.modelToSketchSpace(point)
    except:
        p_sk = point
    p2d = None
    try:
        p2d = adsk.core.Point2D.create(p_sk.x, p_sk.y)
    except:
        p2d = None
    p_sk_flat = None
    try:
        p_sk_flat = adsk.core.Point3D.create(p_sk.x, p_sk.y, 0)
    except:
        p_sk_flat = None
    p_model = None
    try:
        p_model = sketch.sketchToModelSpace(p_sk)
    except:
        p_model = None
    try:
        profiles = sketch.profiles
    except:
        return False
    if not profiles or profiles.count == 0:
        if DEBUG_STUB_ARMS:
            _dbg("WallCenter profiles=0 (no closed profile)")
        return False
    for i in range(profiles.count):
        prof = profiles.item(i)
        if DEBUG_PROFILE_TEST:
            try:
                bb = prof.boundingBox
                area_val = ""
                try:
                    area_val = f" area={prof.area:.3f}"
                except:
                    area_val = ""
                loops_val = ""
                try:
                    loops = prof.profileLoops
                    loop_counts = []
                    for li in range(loops.count):
                        loop = loops.item(li)
                        try:
                            loop_counts.append(str(loop.profileCurves.count))
                        except:
                            loop_counts.append("?")
                    loops_val = " loops=" + ",".join(loop_counts) if loop_counts else ""
                except:
                    loops_val = ""
                if bb and bb.minPoint and bb.maxPoint:
                    _dbg(
                        "WallCenter profile idx="
                        f"{i} bb=({bb.minPoint.x:.3f},{bb.minPoint.y:.3f})"
                        f"-({bb.maxPoint.x:.3f},{bb.maxPoint.y:.3f}){area_val}{loops_val}"
                    )
            except:
                pass
        try:
            if hasattr(prof, "isPointInside"):
                if p2d and prof.isPointInside(p2d):
                    if DEBUG_PROFILE_TEST:
                        _dbg(f"WallCenter hit inside profile idx={i} via=2d")
                    return True
                if prof.isPointInside(p_sk):
                    if DEBUG_PROFILE_TEST:
                        _dbg(f"WallCenter hit inside profile idx={i} via=sketch")
                    return True
                if p_sk_flat and prof.isPointInside(p_sk_flat):
                    if DEBUG_PROFILE_TEST:
                        _dbg(f"WallCenter hit inside profile idx={i} via=flat")
                    return True
                if p_model and prof.isPointInside(p_model):
                    if DEBUG_PROFILE_TEST:
                        _dbg(f"WallCenter hit inside profile idx={i} via=model")
                    return True
        except:
            pass
    tol = TOL * 100.0
    for i in range(profiles.count):
        prof = profiles.item(i)
        poly = _profile_outer_loop_points(prof, tol)
        if DEBUG_PROFILE_TEST:
            try:
                _dbg(f"WallCenter poly idx={i} pts={len(poly)}")
            except:
                pass
        if poly and _point_in_poly_2d(p_sk.x, p_sk.y, poly, tol):
            if DEBUG_PROFILE_TEST:
                _dbg(f"WallCenter hit inside profile idx={i} via=poly")
            return True
    if DEBUG_STUB_ARMS:
        bb_msg = ""
        counts_msg = ""
        curves_total_msg = ""
        p_model_msg = ""
        try:
            if profiles.count > 0:
                bb = profiles.item(0).boundingBox
                if bb and bb.minPoint and bb.maxPoint:
                    bb_msg = (
                        f" bb_min=({bb.minPoint.x:.3f},{bb.minPoint.y:.3f})"
                        f" bb_max=({bb.maxPoint.x:.3f},{bb.maxPoint.y:.3f})"
                    )
        except:
            pass
        min_dist = None
        eval_hits = 0
        if not p_model:
            try:
                p_model = point
            except:
                p_model = None
        try:
            if p_model:
                p_model_msg = (
                    f" p_model=({p_model.x:.3f},{p_model.y:.3f},{p_model.z:.3f})"
                )
        except:
            pass
        try:
            curves = sketch.sketchCurves
            if DEBUG_STUB_ARMS:
                try:
                    counts = [
                        str(getattr(curves, "sketchLines", None).count),
                        str(getattr(curves, "sketchArcs", None).count),
                        str(getattr(curves, "sketchCircles", None).count),
                        str(getattr(curves, "sketchEllipses", None).count),
                        str(getattr(curves, "sketchFittedSplines", None).count),
                        str(getattr(curves, "sketchFixedSplines", None).count),
                        str(getattr(curves, "sketchConics", None).count),
                    ]
                    counts_msg = (
                        " curve_counts=[lines,arcs,circles,ellipses,"
                        "fitted,fix,conics]=" + ",".join(counts)
                    )
                except:
                    pass
                try:
                    curves_total_msg = f" curves_total={curves.count}"
                except:
                    curves_total_msg = " curves_total=?"
            try:
                total = curves.count
            except:
                total = 0
            for i in range(total):
                geo = None
                try:
                    geo = curves.item(i).geometry
                except:
                    geo = None
                if not geo:
                    continue
                obj_type = ""
                try:
                    obj_type = getattr(geo, "objectType", "") or ""
                except:
                    obj_type = ""
                if DEBUG_STUB_ARMS and i < 5:
                    try:
                        has_eval = hasattr(geo, "evaluator")
                        _dbg(f"WallCenter curve[{i}] type={obj_type} has_eval={has_eval}")
                    except:
                        pass
                try:
                    cp = None
                    is_3d = "3D" in obj_type if obj_type else False
                    if is_3d and p_model:
                        try:
                            res = geo.evaluator.getClosestPointTo(p_model)
                            cp = res[1] if isinstance(res, tuple) else res
                        except:
                            cp = None
                    if not cp and p2d:
                        try:
                            res = geo.evaluator.getClosestPointTo(p2d)
                            cp = res[1] if isinstance(res, tuple) else res
                        except:
                            cp = None
                    if not cp:
                        try:
                            res = geo.evaluator.getClosestPointTo(p_sk)
                            cp = res[1] if isinstance(res, tuple) else res
                        except:
                            cp = None
                    if not cp and p_model and not is_3d:
                        try:
                            res = geo.evaluator.getClosestPointTo(p_model)
                            cp = res[1] if isinstance(res, tuple) else res
                        except:
                            cp = None
                    if cp:
                        d = None
                        if p_model:
                            try:
                                d = cp.distanceTo(p_model)
                            except:
                                d = None
                        if d is None:
                            try:
                                d = cp.distanceTo(p2d or p_sk)
                            except:
                                d = None
                        if d is not None:
                            if min_dist is None or d < min_dist:
                                min_dist = d
                        eval_hits += 1
                except:
                    pass
        except:
            pass
        dist_msg = f" min_dist={min_dist:.3f}" if min_dist is not None else ""
        eval_msg = f" eval_hits={eval_hits}" if eval_hits else " eval_hits=0"
        _dbg(
            "WallCenter hit outside all profiles "
            f"p=({p_sk.x:.3f},{p_sk.y:.3f},{p_sk.z:.3f}){p_model_msg}"
            f"{bb_msg}{dist_msg}{eval_msg}"
            f"{counts_msg}{curves_total_msg}"
        )
    return False


def _add_wall_hit_marker(root, entry, point, radius_u, cache):
    if not root or not entry or not point or radius_u <= 0:
        return None
    sk = _get_wall_center_sketch(root, entry, cache)
    if not sk:
        return None
    if not _is_point_inside_sketch_profile(sk, point):
        if DEBUG_STUB_ARMS:
            try:
                _dbg(f"WallCenter hit world=({point.x:.3f},{point.y:.3f},{point.z:.3f})")
            except:
                pass
        return None
    try:
        p_sk = sk.modelToSketchSpace(point)
    except:
        p_sk = point
    try:
        sk.sketchCurves.sketchCircles.addByCenterRadius(p_sk, radius_u)
    except:
        pass
    return sk


def _project_point_to_plane(point, plane_origin, plane_normal):
    n_vec = adsk.core.Vector3D.create(plane_normal.x, plane_normal.y, plane_normal.z)
    if n_vec.length < TOL:
        return None
    n_vec.normalize()
    v = adsk.core.Vector3D.create(
        point.x - plane_origin.x,
        point.y - plane_origin.y,
        point.z - plane_origin.z,
    )
    dist = n_vec.dotProduct(v)
    return adsk.core.Point3D.create(
        point.x - n_vec.x * dist,
        point.y - n_vec.y * dist,
        point.z - n_vec.z * dist,
    )


def _component_axes(body, root):
    occ = None
    try:
        occ = getattr(body, "assemblyContext", None)
    except:
        pass
    if not occ:
        try:
            comp = body.parentComponent
        except:
            comp = None
        occ = _find_occurrence_for_component(root, comp) if comp else None

    x = adsk.core.Vector3D.create(1, 0, 0)
    y = adsk.core.Vector3D.create(0, 1, 0)
    z = adsk.core.Vector3D.create(0, 0, 1)
    if occ:
        try:
            tr = occ.transform
            tr.transformVector(x)
            tr.transformVector(y)
            tr.transformVector(z)
        except:
            pass
    return [_normalise(x), _normalise(y), _normalise(z)]


def _extract_points(res):
    if not res:
        return []
    if isinstance(res, tuple):
        if len(res) >= 2 and isinstance(res[0], bool):
            if not res[0]:
                return []
            return _extract_points(res[1])
        pts = []
        for item in res:
            pts.extend(_extract_points(item))
        return pts
    if hasattr(res, "count") and hasattr(res, "item"):
        pts = []
        for i in range(res.count):
            pts.append(res.item(i))
        return pts
    return [res]


def _line_plane_intersection(origin, direction, plane):
    if not plane or direction.length < TOL:
        return None, None
    n = plane.normal
    if not n or n.length < TOL:
        return None, None
    denom = n.dotProduct(direction)
    if abs(denom) < TOL:
        return None, None
    v = adsk.core.Vector3D.create(
        plane.origin.x - origin.x,
        plane.origin.y - origin.y,
        plane.origin.z - origin.z,
    )
    t = n.dotProduct(v) / denom
    hit = adsk.core.Point3D.create(
        origin.x + direction.x * t,
        origin.y + direction.y * t,
        origin.z + direction.z * t,
    )
    return hit, t


def _is_point_on_face(face, point):
    try:
        ev = face.evaluator
        if hasattr(ev, "isPointOnFace"):
            res = ev.isPointOnFace(point)
            if isinstance(res, tuple):
                return bool(res[0])
            return bool(res)
    except:
        pass
    try:
        if hasattr(face.evaluator, "getClosestPointTo"):
            res = face.evaluator.getClosestPointTo(point)
        else:
            res = face.evaluator.getClosestPoint(point)
    except:
        return False
    if isinstance(res, tuple):
        if not res[0]:
            return False
        cp = res[1]
    else:
        cp = res
    if not cp:
        return False
    return cp.distanceTo(point) <= 1e-3


def _to_local_point(point, occ):
    if not point or not occ:
        return point
    try:
        inv = occ.transform.copy()
        inv.invert()
        p = adsk.core.Point3D.create(point.x, point.y, point.z)
        p.transformBy(inv)
        return p
    except:
        return point


def _to_local_vector(vec, occ):
    if not vec or not occ:
        return vec
    try:
        inv = occ.transform.copy()
        inv.invert()
        v = adsk.core.Vector3D.create(vec.x, vec.y, vec.z)
        inv.transformVector(v)
        return v
    except:
        return vec


def _intersect_ray_with_face(face, origin, direction):
    if direction.length < TOL:
        return None
    d = _normalise(direction)
    plane = _get_face_plane(face)
    if not plane:
        return None
    hit, t = _line_plane_intersection(origin, d, plane)
    if not hit or t <= TOL:
        return None
    return hit


def _intersect_ray_with_faces_onface(origin, direction, faces, sk_cache):
    best = None
    best_t = None
    best_entry = None
    if not faces:
        return None, None
    use_sketch = USE_SKETCH_FALLBACK and sk_cache is not None
    root = ctx.app().activeProduct.rootComponent if use_sketch else None
    for entry in faces:
        face = entry.get("asm") if isinstance(entry, dict) else entry
        if not face:
            continue
        hit = _intersect_ray_with_face(face, origin, direction)
        if not hit:
            continue
        hit_ok = False
        if use_sketch:
            sk = _get_wall_center_sketch(root, entry, sk_cache)
            if sk and _is_point_inside_sketch_profile(sk, hit):
                hit_ok = True
        if not hit_ok and USE_RAY_FALLBACK:
            hit_ok = _is_point_on_face(face, hit)
        if not hit_ok:
            continue
        v = adsk.core.Vector3D.create(
            hit.x - origin.x,
            hit.y - origin.y,
            hit.z - origin.z,
        )
        t = v.dotProduct(direction)
        if t <= TOL:
            continue
        if best_t is None or t < best_t:
            best_t = t
            best = hit
            best_entry = entry
    return best, best_entry


def _segment_hits_wall_before_hit(origin, target, faces, sk_cache, clearance_u):
    if not origin or not target:
        return False
    v = adsk.core.Vector3D.create(
        target.x - origin.x,
        target.y - origin.y,
        target.z - origin.z,
    )
    dist = v.length
    if dist < TOL:
        return False
    d = _normalise(v)
    hit, _ = _intersect_ray_with_faces_onface(origin, d, faces, sk_cache)
    if not hit:
        return False
    t_near = adsk.core.Vector3D.create(
        hit.x - origin.x,
        hit.y - origin.y,
        hit.z - origin.z,
    ).dotProduct(d)
    if t_near <= TOL:
        return False
    if t_near < dist - max(clearance_u, TOL * 10.0):
        return True
    return False


def _adjust_lower_for_clearance(lower, upper, hit, axis_dir, faces, sk_cache, clearance_u):
    if not lower or not upper or not hit:
        return lower, True
    if clearance_u <= TOL:
        return lower, True
    axis = _normalise(axis_dir)
    if not axis:
        return lower, True
    v = adsk.core.Vector3D.create(
        upper.x - lower.x,
        upper.y - lower.y,
        upper.z - lower.z,
    )
    max_shift = v.dotProduct(axis)
    if max_shift <= clearance_u + TOL:
        return lower, False
    cur = lower
    max_steps = int(max_shift / clearance_u) + 2
    for _ in range(max_steps):
        if not _segment_hits_wall_before_hit(cur, hit, faces, sk_cache, clearance_u):
            return cur, True
        cur = _offset_point(cur, axis, clearance_u)
        rem = adsk.core.Vector3D.create(
            upper.x - cur.x,
            upper.y - cur.y,
            upper.z - cur.z,
        ).dotProduct(axis)
        if rem <= clearance_u:
            break
    return lower, False


def _offset_hit_from_wall(hit, upper, hit_entry, inset_u):
    if not hit or not upper or not hit_entry:
        return hit
    if inset_u is None or inset_u <= TOL:
        return hit
    face = hit_entry.get("asm") if isinstance(hit_entry, dict) else hit_entry
    if not face:
        return hit
    plane = _get_face_plane(face)
    if not plane or not plane.normal:
        return hit
    n = _normalise(plane.normal)
    if not n or n.length < TOL:
        return hit
    to_col = adsk.core.Vector3D.create(
        upper.x - hit.x,
        upper.y - hit.y,
        upper.z - hit.z,
    )
    if to_col.length < TOL:
        return hit
    # Flip the wall normal so the inset always moves toward the column.
    if n.dotProduct(to_col) < 0:
        n.scaleBy(-1)
    dist_to_upper = hit.distanceTo(upper)
    inset_use = inset_u
    if dist_to_upper > TOL and inset_use >= dist_to_upper - TOL:
        inset_use = max(0.0, dist_to_upper - TOL)
    if inset_use <= TOL:
        return hit
    return _offset_point(hit, n, inset_use)


def _align_hit_to_upper(hit, upper, axis_dir, hit_entry, sk_cache):
    if not hit or not upper or not axis_dir or not hit_entry:
        return hit, False
    face = hit_entry.get("asm") if isinstance(hit_entry, dict) else hit_entry
    if not face:
        return hit, False
    plane = _get_face_plane(face)
    if not plane or not plane.normal:
        return hit, False
    axis_n = _normalise(axis_dir)
    if not axis_n or axis_n.length < TOL:
        return hit, False
    n = _normalise(plane.normal)
    if not n or n.length < TOL:
        return hit, False
    # Only shift along the column axis when it is close to parallel with the wall plane.
    if abs(n.dotProduct(axis_n)) > 0.2:
        return hit, False
    t_upper = upper.x * axis_n.x + upper.y * axis_n.y + upper.z * axis_n.z
    t_hit = hit.x * axis_n.x + hit.y * axis_n.y + hit.z * axis_n.z
    shift = t_upper - t_hit
    if abs(shift) <= TOL:
        return hit, False
    cand = adsk.core.Point3D.create(
        hit.x + axis_n.x * shift,
        hit.y + axis_n.y * shift,
        hit.z + axis_n.z * shift,
    )
    if _is_point_on_face(face, cand):
        return cand, True
    if USE_SKETCH_FALLBACK and sk_cache is not None:
        sk = _get_wall_center_sketch(ctx.app().activeProduct.rootComponent, hit_entry, sk_cache)
        if sk and _is_point_inside_sketch_profile(sk, cand):
            return cand, True
    return hit, False


def _line_dir_for_face(face_normal, axis_dir, comp_axes):
    n = _normalise(face_normal)
    axis_n = _normalise(axis_dir)
    for axis in comp_axes:
        if abs(axis.dotProduct(n)) > 0.2:
            continue
        if abs(axis.dotProduct(axis_n)) > 0.2:
            continue
        return _normalise(axis)
    d = axis_n.crossProduct(n)
    if d.length < TOL:
        return None
    d.normalize()
    return d


def _face_span_along_dir(face, direction):
    if not face or direction.length < TOL:
        return None
    d = _normalise(direction)
    min_t = None
    max_t = None
    try:
        verts = face.vertices
    except:
        verts = None
    if not verts or verts.count == 0:
        return None
    for i in range(verts.count):
        p = verts.item(i).geometry
        t = p.x * d.x + p.y * d.y + p.z * d.z
        if min_t is None:
            min_t = max_t = t
        else:
            min_t = min(min_t, t)
            max_t = max(max_t, t)
    if min_t is None:
        return None
    return max_t - min_t




def _find_occurrence_for_component(root, comp):
    if not root or not comp:
        return None
    try:
        occs = root.allOccurrences
        for i in range(occs.count):
            occ = occs.item(i)
            if occ.component == comp:
                return occ
    except:
        pass
    return None


def _proxy_body(body, root):
    if not body:
        return None
    try:
        if getattr(body, "assemblyContext", None):
            return body
    except:
        pass
    try:
        comp = body.parentComponent
    except:
        comp = None
    occ = _find_occurrence_for_component(root, comp) if comp else None
    if occ:
        try:
            return body.createForAssemblyContext(occ)
        except:
            return None
    return body


def _proxy_face(face, root):
    if not face:
        return None
    try:
        if getattr(face, "assemblyContext", None):
            return face
    except:
        pass
    try:
        comp = face.body.parentComponent
    except:
        comp = None
    occ = _find_occurrence_for_component(root, comp) if comp else None
    if occ:
        try:
            return face.createForAssemblyContext(occ)
        except:
            return None
    return face


def _collect_column_faces(sel_input, root):
    faces = {}
    bodies = []
    for i in range(sel_input.selectionCount):
        ent = sel_input.selection(i).entity
        face = adsk.fusion.BRepFace.cast(ent)
        if face:
            asm = _proxy_face(face, root)
            if not asm:
                continue
            try:
                key = asm.entityToken
            except:
                key = id(asm)
            if key not in faces:
                faces[key] = asm
            continue
        body = adsk.fusion.BRepBody.cast(ent)
        if body:
            body = _proxy_body(body, root)
            if body:
                bodies.append(body)
            continue
        occ = adsk.fusion.Occurrence.cast(ent)
        if occ:
            try:
                bodies_coll = occ.component.bRepBodies
            except:
                bodies_coll = None
            if not bodies_coll:
                continue
            for j in range(bodies_coll.count):
                b = bodies_coll.item(j)
                try:
                    b_asm = b.createForAssemblyContext(occ)
                except:
                    b_asm = None
                if b_asm:
                    bodies.append(b_asm)
            continue
    return list(faces.values()), bodies


def _collect_wall_faces(sel_input, root):
    faces = {}
    for i in range(sel_input.selectionCount):
        ent = sel_input.selection(i).entity
        face = adsk.fusion.BRepFace.cast(ent)
        if face:
            occ = getattr(face, "assemblyContext", None)
            native = getattr(face, "nativeObject", None) or face
            asm = face if occ else _proxy_face(face, root)
            if not asm:
                continue
            try:
                key = asm.entityToken
            except:
                key = id(asm)
            faces[key] = {
                "asm": asm,
                "native": native,
                "occ": occ,
            }
            continue
        body = adsk.fusion.BRepBody.cast(ent)
        if body:
            body = _proxy_body(body, root)
            if not body:
                continue
            for j in range(body.faces.count):
                f = body.faces.item(j)
                occ = getattr(f, "assemblyContext", None)
                native = getattr(f, "nativeObject", None) or f
                asm = f if occ else _proxy_face(f, root)
                if not asm:
                    continue
                try:
                    key = asm.entityToken
                except:
                    key = id(asm)
                faces[key] = {
                    "asm": asm,
                    "native": native,
                    "occ": occ,
                }
            continue
        occ = adsk.fusion.Occurrence.cast(ent)
        if occ:
            try:
                bodies = occ.component.bRepBodies
            except:
                bodies = None
            if not bodies:
                continue
            for j in range(bodies.count):
                b = bodies.item(j)
                try:
                    fcount = b.faces.count
                except:
                    fcount = 0
                if fcount == 0:
                    continue
                b_asm = b.createForAssemblyContext(occ)
                for k in range(b_asm.faces.count):
                    f = b_asm.faces.item(k)
                    occ_f = getattr(f, "assemblyContext", None)
                    native_f = getattr(f, "nativeObject", None) or f
                    asm_f = f if occ_f else _proxy_face(f, root)
                    if not asm_f:
                        continue
                    try:
                        key = asm_f.entityToken
                    except:
                        key = id(asm_f)
                    faces[key] = {
                        "asm": asm_f,
                        "native": native_f,
                        "occ": occ_f,
                    }
            continue
        comp = adsk.fusion.Component.cast(ent)
        if comp:
            occ = _find_occurrence_for_component(root, comp)
            if not occ:
                continue
            try:
                bodies = comp.bRepBodies
            except:
                bodies = None
            if not bodies:
                continue
            for j in range(bodies.count):
                b = bodies.item(j)
                try:
                    fcount = b.faces.count
                except:
                    fcount = 0
                if fcount == 0:
                    continue
                b_asm = b.createForAssemblyContext(occ)
                for k in range(b_asm.faces.count):
                    f = b_asm.faces.item(k)
                    occ_f = getattr(f, "assemblyContext", None)
                    native_f = getattr(f, "nativeObject", None) or f
                    asm_f = f if occ_f else _proxy_face(f, root)
                    if not asm_f:
                        continue
                    try:
                        key = asm_f.entityToken
                    except:
                        key = id(asm_f)
                    faces[key] = {
                        "asm": asm_f,
                        "native": native_f,
                        "occ": occ_f,
                    }
    return list(faces.values())


def _next_sketch_name(comp, base):
    existing = set()
    sketches = getattr(comp, "sketches", None)
    if not sketches:
        return base
    for i in range(sketches.count):
        try:
            existing.add(sketches.item(i).name)
        except:
            pass
    if base not in existing:
        return base
    idx = 2
    while f"{base} {idx}" in existing:
        idx += 1
    return f"{base} {idx}"


def _face_area(face):
    if not face:
        return 0.0
    try:
        return face.area
    except:
        pass
    try:
        ap = face.areaProperties
        if ap:
            return ap.area
    except:
        pass
    return 0.0


def _face_is_side(face, axis_dir):
    if not face or not axis_dir:
        return False
    plane = _get_face_plane(face)
    if not plane or not plane.normal:
        return False
    n = _normalise(plane.normal)
    a = _normalise(axis_dir)
    if not n or not a:
        return False
    return abs(n.dotProduct(a)) < 0.3


def _get_or_create_stub_component(root):
    if not root:
        return None
    target = None
    try:
        occs = root.occurrences
        for i in range(occs.count):
            occ = occs.item(i)
            try:
                if occ.component and occ.component.name.lower() == STUB_LINES_COMPONENT_NAME.lower():
                    target = occ.component
                    break
            except:
                continue
    except:
        pass
    if target:
        return target
    try:
        occ = root.occurrences.addNewComponent(adsk.core.Matrix3D.create())
        comp = occ.component
        comp.name = STUB_LINES_COMPONENT_NAME
        return comp
    except:
        return None


def _component_label_for_body(body):
    if not body:
        return "<unnamed>"
    try:
        occ = getattr(body, "assemblyContext", None)
        if occ and occ.component and occ.component.name:
            return occ.component.name
    except:
        pass
    try:
        comp = body.parentComponent
        if comp and comp.name:
            return comp.name
    except:
        pass
    try:
        name = body.name
        if name:
            return name
    except:
        pass
    return "<unnamed>"


def _create_stub_sketch(stub_comp, face, root):
    if not stub_comp:
        return None
    sk = None
    plane = _get_face_plane(face)
    if plane:
        try:
            sk = stub_comp.sketches.add(plane)
        except:
            sk = None
    if not sk:
        try:
            sk = stub_comp.sketches.add(face)
        except:
            sk = None
    if not sk:
        try:
            sk = root.sketches.add(face)
        except:
            sk = None
    return sk


def _choose_column_face(body, root, wall_faces, wall_sketches):
    if not body:
        return None
    axis = _get_body_axis(body)
    axis_dir, bottom, top, length = _axis_endpoints(body, axis) if axis else (None, None, None, None)
    if not axis_dir or not bottom or not top:
        return None
    comp_axes = _component_axes(body, root)
    candidates = []
    try:
        faces = body.faces
    except:
        faces = None
    if not faces:
        return None
    max_area = 0.0
    for i in range(faces.count):
        f = faces.item(i)
        if not _face_is_side(f, axis_dir):
            continue
        area = _face_area(f)
        if area > max_area:
            max_area = area
        candidates.append((f, area))
    if not candidates:
        return None
    area_tol = max_area * 0.01
    top_faces = [f for f, a in candidates if a >= max_area - area_tol]
    if len(top_faces) == 1:
        return top_faces[0]
    best = None
    best_hits = -1
    best_avg = None
    for f in top_faces:
        plane = _get_face_plane(f)
        if not plane:
            continue
        line_dir = _line_dir_for_face(plane.normal, axis_dir, comp_axes)
        if not line_dir:
            continue
        wall_dir = _normalise(line_dir)
        hits = 0
        dist_sum = 0.0
        for t in (0.2, 0.5, 0.8):
            p = _offset_point(bottom, axis_dir, length * t)
            hit, _ = _intersect_ray_with_faces_onface(p, wall_dir, wall_faces, wall_sketches)
            if not hit:
                neg_dir = adsk.core.Vector3D.create(-wall_dir.x, -wall_dir.y, -wall_dir.z)
                hit, _ = _intersect_ray_with_faces_onface(p, neg_dir, wall_faces, wall_sketches)
            if hit:
                v = adsk.core.Vector3D.create(hit.x - p.x, hit.y - p.y, hit.z - p.z)
                hits += 1
                dist_sum += abs(v.dotProduct(wall_dir))
        if hits > 0:
            avg = dist_sum / float(hits)
            if hits > best_hits or (hits == best_hits and (best_avg is None or avg < best_avg)):
                best_hits = hits
                best_avg = avg
                best = f
    if best:
        return best
    return top_faces[0]


def _execute(args):
    design = adsk.fusion.Design.cast(ctx.app().activeProduct)
    if not design:
        ctx.ui().messageBox("No active design.")
        return
    root = design.rootComponent
    um = design.unitsManager

    cmd = args.command
    inputs = cmd.commandInputs

    sel_cols = adsk.core.SelectionCommandInput.cast(inputs.itemById("stub_cols"))
    sel_wall = adsk.core.SelectionCommandInput.cast(inputs.itemById("stub_wall"))
    count_in = adsk.core.IntegerSpinnerCommandInput.cast(inputs.itemById("stub_points"))

    if not sel_cols or sel_cols.selectionCount == 0:
        ctx.ui().messageBox("Select at least one RHS column face.")
        return
    if not sel_wall or sel_wall.selectionCount == 0:
        ctx.ui().messageBox("Select at least one wall face or body.")
        return

    def mm_val(cid):
        v = adsk.core.ValueCommandInput.cast(inputs.itemById(cid))
        return um.convert(v.value, um.internalUnits, "mm")

    bottom_mm = mm_val("stub_bottom")
    top_mm = mm_val("stub_top")
    desired_count = count_in.value if count_in else 6
    min_mm = mm_val("stub_min_spacing")
    max_mm = mm_val("stub_max_spacing")
    if min_mm <= 0 or max_mm <= 0:
        ctx.ui().messageBox("Min/Max spacing must be greater than 0 mm.")
        return
    if min_mm > max_mm:
        ctx.ui().messageBox("Min spacing must be less than or equal to max spacing.")
        return

    bottom_u = um.convert(bottom_mm, "mm", um.internalUnits)
    top_u = um.convert(top_mm, "mm", um.internalUnits)
    clearance_mm = mm_val("stub_clearance")
    clearance_u = um.convert(clearance_mm, "mm", um.internalUnits)
    wall_inset_mm_raw = mm_val("stub_wall_inset")
    wall_inset_mm = max(0.0, wall_inset_mm_raw)
    if wall_inset_mm_raw < 0 and DEBUG_STUB_ARMS:
        _dbg(f"Wall inset was negative ({wall_inset_mm_raw:.2f} mm); clamped to 0")
    wall_inset_u = um.convert(wall_inset_mm, "mm", um.internalUnits)
    min_spacing_u = um.convert(min_mm, "mm", um.internalUnits)
    max_spacing_u = um.convert(max_mm, "mm", um.internalUnits)

    faces, bodies = _collect_column_faces(sel_cols, root)
    if not faces and not bodies:
        ctx.ui().messageBox("No valid RHS/SHS faces selected.")
        return
    wall_faces = _collect_wall_faces(sel_wall, root)
    if not wall_faces:
        ctx.ui().messageBox("No valid wall faces selected.")
        return

    _dbg(
        f"Selected faces={len(faces)}, wall_faces={len(wall_faces)}, "
        f"points={desired_count}, spacing_mm=[{min_mm},{max_mm}], "
        f"wall_inset_mm={wall_inset_mm}"
    )

    logger.log_command(
        CMD_NAME,
        {
            "faces": len(faces),
            "wall_faces": len(wall_faces),
            "points_requested": desired_count,
            "min_spacing_mm": min_mm,
            "max_spacing_mm": max_mm,
            "bottom_mm": bottom_mm,
            "top_mm": top_mm,
            "wall_inset_mm": wall_inset_mm,
        },
    )

    _save_stub_settings(
        root,
        {
            "points": desired_count,
            "min_spacing_mm": min_mm,
            "max_spacing_mm": max_mm,
            "bottom_mm": bottom_mm,
            "top_mm": top_mm,
            "clearance_mm": clearance_mm,
            "wall_inset_mm": wall_inset_mm,
        },
    )

    use_wall_sketches = USE_SKETCH_FALLBACK or DEBUG_WALL_MARKERS
    wall_center_sketches = {} if use_wall_sketches else None
    stub_comp = _get_or_create_stub_component(root)
    if not stub_comp:
        ctx.ui().messageBox("Failed to create or find 'stub arm lines' component.")
        return
    hit_marker_radius_u = None
    if DEBUG_WALL_MARKERS and wall_center_sketches is not None:
        hit_marker_radius_u = um.convert(6.0, "mm", um.internalUnits)
        for entry in wall_faces:
            sk = _get_wall_center_sketch(root, entry, wall_center_sketches)
            if sk and DEBUG_STUB_ARMS:
                _dbg(f"Wall marker sketch='{sk.name}'")

    lines_created = 0
    cols_skipped = []
    pair_missed = 0

    for face in faces:
        body = face.body
        label = _component_label_for_body(body)
        plane = _get_face_plane(face)
        if not plane:
            _dbg(f"Skip body='{label}': selected face not planar")
            cols_skipped.append(label)
            continue

        axis = _get_body_axis(body)
        axis_dir, bottom, top, length = _axis_endpoints(body, axis) if axis else (None, None, None, None)
        if not axis_dir or not bottom or not top or not length:
            _dbg(f"Skip body='{label}': axis/length invalid")
            cols_skipped.append(label)
            continue

        if not _looks_like_rhs_shs(body, axis_dir):
            _dbg(f"Skip body='{label}': not RHS/SHS (name/geometry check failed)")
            cols_skipped.append(label)
            continue

        comp_axes = _component_axes(body, root)

        span = length - bottom_u - top_u
        if span <= TOL:
            _dbg(f"Skip body='{label}': span={span:.4f}")
            cols_skipped.append(label)
            continue
        count, spacing, adjusted, _, _, in_range = _resolve_point_spacing(
            span, desired_count, min_spacing_u, max_spacing_u
        )
        if count < 2 or not spacing or spacing <= TOL:
            _dbg(f"Skip body='{label}': spacing={spacing} count={count}")
            cols_skipped.append(label)
            continue
        if not in_range:
            spacing_mm = um.convert(spacing, um.internalUnits, "mm")
            span_mm = um.convert(span, um.internalUnits, "mm")
            _dbg(
                f"Skip body='{label}': spacing_mm={spacing_mm:.1f} "
                f"outside [{min_mm},{max_mm}] span_mm={span_mm:.1f}"
            )
            cols_skipped.append(label)
            continue
        if adjusted:
            spacing_mm = um.convert(spacing, um.internalUnits, "mm")
            _dbg(
                f"Body='{label}': adjusted points {desired_count}->{count} "
                f"spacing_mm={spacing_mm:.1f}"
            )

        points = []
        for i in range(count):
            dist = bottom_u + spacing * i
            points.append(_offset_point(bottom, axis_dir, dist))

        _dbg(
            f"Body='{label}' axis=({axis_dir.x:.4f},{axis_dir.y:.4f},{axis_dir.z:.4f}) "
            f"len={length:.4f} bottom=({bottom.x:.4f},{bottom.y:.4f},{bottom.z:.4f}) "
            f"top=({top.x:.4f},{top.y:.4f},{top.z:.4f}) spacing={spacing:.4f}"
        )
        line_dir = _line_dir_for_face(plane.normal, axis_dir, comp_axes)
        if not line_dir:
            _dbg(f"Skip body='{label}': line dir invalid")
            cols_skipped.append(label)
            continue
        wall_dir = _normalise(line_dir)

        span = _face_span_along_dir(face, line_dir)
        face_points = []
        for p in points:
            p_on = _project_point_to_plane(p, plane.origin, plane.normal)
            if not p_on:
                continue
            face_points.append(p_on)

        pair_hits = []

        for i in range(len(face_points) - 1):
            lower = face_points[i]
            upper = face_points[i + 1]
            mid = adsk.core.Point3D.create(
                (upper.x + lower.x) * 0.5,
                (upper.y + lower.y) * 0.5,
                (upper.z + lower.z) * 0.5,
            )

            hit = None
            hit_entry = None
            hit_from = "upper"
            hit, hit_entry = _intersect_ray_with_faces_onface(
                upper, wall_dir, wall_faces, wall_center_sketches
            )
            if not hit:
                hit_from = "lower"
                hit, hit_entry = _intersect_ray_with_faces_onface(
                    lower, wall_dir, wall_faces, wall_center_sketches
                )
            if not hit:
                hit_from = "mid"
                hit, hit_entry = _intersect_ray_with_faces_onface(
                    mid, wall_dir, wall_faces, wall_center_sketches
                )
            if not hit:
                neg_dir = adsk.core.Vector3D.create(-wall_dir.x, -wall_dir.y, -wall_dir.z)
                hit_from = "upper_neg"
                hit, hit_entry = _intersect_ray_with_faces_onface(
                    upper, neg_dir, wall_faces, wall_center_sketches
                )
                if not hit:
                    hit_from = "lower_neg"
                    hit, hit_entry = _intersect_ray_with_faces_onface(
                        lower, neg_dir, wall_faces, wall_center_sketches
                    )
                if not hit:
                    hit_from = "mid_neg"
                    hit, hit_entry = _intersect_ray_with_faces_onface(
                        mid, neg_dir, wall_faces, wall_center_sketches
                    )
            if not hit:
                if DEBUG_STUB_ARMS and wall_faces:
                    wf = wall_faces[0]
                    asm_face = wf["asm"]
                    native_face = wf["native"]
                    occ = wf["occ"]
                    plane_w = _get_face_plane(asm_face)
                    n_w = _normalise(plane_w.normal) if plane_w and plane_w.normal else None
                    if occ:
                        mid_l = _to_local_point(mid, occ)
                        dir_l = _to_local_vector(line_dir, occ)
                        plane_l = _get_face_plane(native_face)
                        n_l = _normalise(plane_l.normal) if plane_l and plane_l.normal else None
                        _dbg(
                            f"Missed pair {i}: mid_w=({mid.x:.3f},{mid.y:.3f},{mid.z:.3f}) "
                            f"dir_w=({wall_dir.x:.3f},{wall_dir.y:.3f},{wall_dir.z:.3f}) "
                            f"wall_n_w=({n_w.x:.3f},{n_w.y:.3f},{n_w.z:.3f}) "
                            f"mid_l=({mid_l.x:.3f},{mid_l.y:.3f},{mid_l.z:.3f}) "
                            f"dir_l=({dir_l.x:.3f},{dir_l.y:.3f},{dir_l.z:.3f}) "
                            f"wall_n_l=({n_l.x:.3f},{n_l.y:.3f},{n_l.z:.3f})"
                        )
                    else:
                        _dbg(
                            f"Missed pair {i}: mid=({mid.x:.3f},{mid.y:.3f},{mid.z:.3f}) "
                            f"dir=({wall_dir.x:.3f},{wall_dir.y:.3f},{wall_dir.z:.3f}) "
                            f"wall_n=({n_w.x:.3f},{n_w.y:.3f},{n_w.z:.3f})"
                        )
                pair_missed += 1
                continue
            if not hit_from.startswith("upper"):
                hit_aligned, aligned = _align_hit_to_upper(
                    hit, upper, axis_dir, hit_entry, wall_center_sketches
                )
                if aligned:
                    hit = hit_aligned
                    hit_from = f"{hit_from}_aligned"
                else:
                    if DEBUG_STUB_ARMS:
                        _dbg(f"Pair {i}: hit from {hit_from} could not align to upper; skipped")
                    pair_missed += 1
                    continue
            hit_before_inset = hit
            hit = _offset_hit_from_wall(hit, upper, hit_entry, wall_inset_u)
            if DEBUG_STUB_ARMS and hit_before_inset and hit:
                inset_applied_u = hit_before_inset.distanceTo(hit)
                if inset_applied_u > TOL:
                    inset_applied_mm = um.convert(inset_applied_u, um.internalUnits, "mm")
                    _dbg(f"Pair {i}: wall inset applied mm={inset_applied_mm:.2f}")
            if DEBUG_STUB_ARMS:
                _dbg(f"Pair {i}: wall hit from {hit_from}")
            if DEBUG_WALL_MARKERS and wall_center_sketches and hit_entry and hit_marker_radius_u:
                _add_wall_hit_marker(root, hit_entry, hit, hit_marker_radius_u, wall_center_sketches)
            lower_adj, draw_lower = _adjust_lower_for_clearance(
                lower, upper, hit, axis_dir, wall_faces, wall_center_sketches, clearance_u
            )
            arm_dir = adsk.core.Vector3D.create(
                hit.x - upper.x,
                hit.y - upper.y,
                hit.z - upper.z,
            )
            bracket_type = _bracket_type_for_faces(hit_entry, arm_dir, line_dir)
            pair_hits.append((i, lower_adj, upper, hit, draw_lower, bracket_type))

        if not pair_hits:
            continue

        sketch_by_type = {}
        sketch_failed = False
        for _, lower, upper, hit, draw_lower, bracket_type in pair_hits:
            if sketch_failed:
                break
            btype = "square" if bracket_type == "square" else "swivel"
            sk = sketch_by_type.get(btype)
            if not sk:
                sk = _create_stub_sketch(stub_comp, face, root)
                if not sk:
                    _dbg(f"Skip body='{label}': failed to create stub sketch for {btype}")
                    cols_skipped.append(label)
                    sketch_failed = True
                    break
                try:
                    sk.name = _next_sketch_name(stub_comp, f"Stub Arms - {label} - {btype.title()}")
                except:
                    pass
                _disable_sketch_profiles(sk)
                sketch_by_type[btype] = sk
            lines = sk.sketchCurves.sketchLines
            try:
                upper_sk = sk.modelToSketchSpace(upper)
                lower_sk = sk.modelToSketchSpace(lower)
                hit_sk = sk.modelToSketchSpace(hit)
            except:
                upper_sk = upper
                lower_sk = lower
                hit_sk = hit
            upper_line = lines.addByTwoPoints(upper_sk, hit_sk)
            _tag_stub_line(upper_line, "FlatBar")
            _tag_stub_bracket(upper_line, bracket_type, True)
            if draw_lower:
                lower_line = lines.addByTwoPoints(lower_sk, hit_sk)
                _tag_stub_line(lower_line, "EA")
                lines_created += 2
            else:
                lines_created += 1

    for body in bodies:
        label = _component_label_for_body(body)
        face = _choose_column_face(body, root, wall_faces, wall_center_sketches)
        if not face:
            _dbg(f"Skip body='{label}': no suitable side face")
            cols_skipped.append(label)
            continue
        plane = _get_face_plane(face)
        if not plane:
            _dbg(f"Skip body='{label}': selected face not planar")
            cols_skipped.append(label)
            continue
        axis = _get_body_axis(body)
        axis_dir, bottom, top, length = _axis_endpoints(body, axis) if axis else (None, None, None, None)
        if not axis_dir or not bottom or not top or not length:
            _dbg(f"Skip body='{label}': axis/length invalid")
            cols_skipped.append(label)
            continue
        if not _looks_like_rhs_shs(body, axis_dir):
            _dbg(f"Skip body='{label}': not RHS/SHS (name/geometry check failed)")
            cols_skipped.append(label)
            continue

        comp_axes = _component_axes(body, root)
        span = length - bottom_u - top_u
        if span <= TOL:
            _dbg(f"Skip body='{label}': span={span:.4f}")
            cols_skipped.append(label)
            continue
        count, spacing, adjusted, _, _, in_range = _resolve_point_spacing(
            span, desired_count, min_spacing_u, max_spacing_u
        )
        if count < 2 or not spacing or spacing <= TOL:
            _dbg(f"Skip body='{label}': spacing={spacing} count={count}")
            cols_skipped.append(label)
            continue
        if not in_range:
            spacing_mm = um.convert(spacing, um.internalUnits, "mm")
            span_mm = um.convert(span, um.internalUnits, "mm")
            _dbg(
                f"Skip body='{label}': spacing_mm={spacing_mm:.1f} "
                f"outside [{min_mm},{max_mm}] span_mm={span_mm:.1f}"
            )
            cols_skipped.append(label)
            continue
        if adjusted:
            spacing_mm = um.convert(spacing, um.internalUnits, "mm")
            _dbg(
                f"Body='{label}': adjusted points {desired_count}->{count} "
                f"spacing_mm={spacing_mm:.1f}"
            )

        points = []
        for i in range(count):
            dist = bottom_u + spacing * i
            points.append(_offset_point(bottom, axis_dir, dist))

        _dbg(
            f"Body='{label}' axis=({axis_dir.x:.4f},{axis_dir.y:.4f},{axis_dir.z:.4f}) "
            f"len={length:.4f} bottom=({bottom.x:.4f},{bottom.y:.4f},{bottom.z:.4f}) "
            f"top=({top.x:.4f},{top.y:.4f},{top.z:.4f}) spacing={spacing:.4f}"
        )
        line_dir = _line_dir_for_face(plane.normal, axis_dir, comp_axes)
        if not line_dir:
            _dbg(f"Skip body='{label}': line dir invalid")
            cols_skipped.append(label)
            continue
        wall_dir = _normalise(line_dir)

        span = _face_span_along_dir(face, line_dir)
        face_points = []
        for p in points:
            p_on = _project_point_to_plane(p, plane.origin, plane.normal)
            if not p_on:
                continue
            face_points.append(p_on)

        pair_hits = []
        for i in range(len(face_points) - 1):
            lower = face_points[i]
            upper = face_points[i + 1]
            mid = adsk.core.Point3D.create(
                (upper.x + lower.x) * 0.5,
                (upper.y + lower.y) * 0.5,
                (upper.z + lower.z) * 0.5,
            )

            hit = None
            hit_entry = None
            hit_from = "upper"
            hit, hit_entry = _intersect_ray_with_faces_onface(
                upper, wall_dir, wall_faces, wall_center_sketches
            )
            if not hit:
                hit_from = "lower"
                hit, hit_entry = _intersect_ray_with_faces_onface(
                    lower, wall_dir, wall_faces, wall_center_sketches
                )
            if not hit:
                hit_from = "mid"
                hit, hit_entry = _intersect_ray_with_faces_onface(
                    mid, wall_dir, wall_faces, wall_center_sketches
                )
            if not hit:
                neg_dir = adsk.core.Vector3D.create(-wall_dir.x, -wall_dir.y, -wall_dir.z)
                hit_from = "upper_neg"
                hit, hit_entry = _intersect_ray_with_faces_onface(
                    upper, neg_dir, wall_faces, wall_center_sketches
                )
                if not hit:
                    hit_from = "lower_neg"
                    hit, hit_entry = _intersect_ray_with_faces_onface(
                        lower, neg_dir, wall_faces, wall_center_sketches
                    )
                if not hit:
                    hit_from = "mid_neg"
                    hit, hit_entry = _intersect_ray_with_faces_onface(
                        mid, neg_dir, wall_faces, wall_center_sketches
                    )
            if not hit:
                pair_missed += 1
                continue
            if not hit_from.startswith("upper"):
                hit_aligned, aligned = _align_hit_to_upper(
                    hit, upper, axis_dir, hit_entry, wall_center_sketches
                )
                if aligned:
                    hit = hit_aligned
                    hit_from = f"{hit_from}_aligned"
                else:
                    if DEBUG_STUB_ARMS:
                        _dbg(f"Pair {i}: hit from {hit_from} could not align to upper; skipped")
                    pair_missed += 1
                    continue
            hit_before_inset = hit
            hit = _offset_hit_from_wall(hit, upper, hit_entry, wall_inset_u)
            if DEBUG_STUB_ARMS and hit_before_inset and hit:
                inset_applied_u = hit_before_inset.distanceTo(hit)
                if inset_applied_u > TOL:
                    inset_applied_mm = um.convert(inset_applied_u, um.internalUnits, "mm")
                    _dbg(f"Pair {i}: wall inset applied mm={inset_applied_mm:.2f}")
            if DEBUG_STUB_ARMS:
                _dbg(f"Pair {i}: wall hit from {hit_from}")
            if DEBUG_WALL_MARKERS and wall_center_sketches and hit_entry and hit_marker_radius_u:
                _add_wall_hit_marker(root, hit_entry, hit, hit_marker_radius_u, wall_center_sketches)
            lower_adj, draw_lower = _adjust_lower_for_clearance(
                lower, upper, hit, axis_dir, wall_faces, wall_center_sketches, clearance_u
            )
            arm_dir = adsk.core.Vector3D.create(
                hit.x - upper.x,
                hit.y - upper.y,
                hit.z - upper.z,
            )
            bracket_type = _bracket_type_for_faces(hit_entry, arm_dir, line_dir)
            pair_hits.append((i, lower_adj, upper, hit, draw_lower, bracket_type))

        if not pair_hits:
            continue

        sketch_by_type = {}
        sketch_failed = False
        for _, lower, upper, hit, draw_lower, bracket_type in pair_hits:
            if sketch_failed:
                break
            btype = "square" if bracket_type == "square" else "swivel"
            sk = sketch_by_type.get(btype)
            if not sk:
                sk = _create_stub_sketch(stub_comp, face, root)
                if not sk:
                    _dbg(f"Skip body='{label}': failed to create stub sketch for {btype}")
                    cols_skipped.append(label)
                    sketch_failed = True
                    break
                try:
                    sk.name = _next_sketch_name(stub_comp, f"Stub Arms - {label} - {btype.title()}")
                except:
                    pass
                _disable_sketch_profiles(sk)
                sketch_by_type[btype] = sk
            lines = sk.sketchCurves.sketchLines
            try:
                upper_sk = sk.modelToSketchSpace(upper)
                lower_sk = sk.modelToSketchSpace(lower)
                hit_sk = sk.modelToSketchSpace(hit)
            except:
                upper_sk = upper
                lower_sk = lower
                hit_sk = hit
            upper_line = lines.addByTwoPoints(upper_sk, hit_sk)
            _tag_stub_line(upper_line, "FlatBar")
            _tag_stub_bracket(upper_line, bracket_type, True)
            if draw_lower:
                lower_line = lines.addByTwoPoints(lower_sk, hit_sk)
                _tag_stub_line(lower_line, "EA")
                lines_created += 2
            else:
                lines_created += 1

    if wall_center_sketches:
        for sk in wall_center_sketches.values():
            try:
                sk.deleteMe()
            except:
                pass

    try:
        ctx.app().activeViewport.refresh()
    except:
        pass

    msg = [f"Created {lines_created} stub arm line(s)."]
    if cols_skipped:
        msg.append("Skipped columns:\n  " + "\n  ".join(sorted(set(cols_skipped))))
    if pair_missed:
        msg.append(f"Missed {pair_missed} pair(s) (no wall hit).")
    ctx.ui().messageBox("\n\n".join(msg))


def register(ui, panel):
    cmd_def = ui.commandDefinitions.itemById(CMD_ID)
    if not cmd_def:
        cmd_def = ui.commandDefinitions.addButtonDefinition(
            CMD_ID, CMD_NAME, CMD_TOOLTIP, RESOURCE_FOLDER
        )

    created_handler = StubArmsCreatedHandler()
    cmd_def.commandCreated.add(created_handler)
    ctx.add_handler(created_handler)

    if not panel.controls.itemById(CMD_ID):
        ctrl = panel.controls.addCommand(cmd_def)
        ctrl.isPromoted = True
        ctrl.isPromotedByDefault = True
